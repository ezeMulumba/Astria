package com.astria.assistant

import com.astria.assistant.CommandParser.Command
import com.astria.assistant.CommandParser.Type
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Le « cerveau » d'Astria : quand ses règles locales ne comprennent pas une phrase, Gemini la
 * traduit en une commande structurée (la même que celles des règles locales), qu'Astria exécute
 * ensuite avec ses propres fonctions et après votre confirmation vocale.
 * Gemini ne commande JAMAIS le téléphone directement : il ne fait que comprendre la phrase.
 * Fonctionne seulement si une clé Gemini est enregistrée dans les réglages d'Astria.
 * Ces fonctions bloquent : à appeler hors du fil principal.
 */
object Brain {

    private val FIELDS = listOf(
        "recipient", "message", "name", "app", "url", "query", "city", "tomorrow", "title",
        "date", "target", "action", "dir", "state", "hour", "minute", "seconds", "offset"
    )

    private fun instructions(): String {
        val today = SimpleDateFormat("EEEE d MMMM yyyy (yyyy-MM-dd)", Locale.FRENCH).format(Date())
        return """
Tu es le moteur de compréhension d'Astria, une assistante vocale Android. Tu reçois UNE phrase en français,
parfois mal transcrite par la reconnaissance vocale. Tu réponds UNIQUEMENT par un objet JSON, sans texte autour.

Format : {"type": "<TYPE>", "<champ>": "<valeur>", ...}   (toutes les valeurs en chaînes de caractères)

Types et champs :
- TIME, DATE, BATTERY : aucun champ
- WEATHER : city (facultatif), tomorrow ("1" ou "0")
- ALARM : hour (0-23), minute (0-59)
- TIMER : seconds (nombre total de secondes)
- CALL : recipient (nom du contact)
- SMS : recipient, message
- SOCIAL : app (whatsapp, telegram, messenger, instagram, facebook, x, linkedin), recipient, message
- READ_SMS : aucun champ
- CONTACT_INFO : name (nom du contact dont on veut le numéro)
- CAL_READ : offset ("0" aujourd'hui, "1" demain, "2" après-demain)
- CAL_ADD : title, date (format yyyy-MM-dd), hour, minute
- OPEN_APP : name (nom de l'application ; pour la galerie ou les photos écris "galerie", pour la calculatrice écris "calculatrice", pour le répertoire écris "contacts")
- OPEN_URL : url (adresse complète en https)
- GOOGLE : query (ce qu'il faut chercher sur Google dans le navigateur)
- WEB_ASK : query (question de culture générale, conversation, blague, conseil, tout ce qui demande une réponse parlée)
- FLASHLIGHT : state ("on" ou "off")
- VOLUME : dir ("up", "down", "max" ou "mute")
- NAV : action ("home", "back", "recents", "notifs", "lock" ou "screenshot")
- SETTINGS : target ("wifi", "bluetooth", "data", "airplane", "display" ou "general")
- CANCEL : l'utilisateur renonce
- UNKNOWN : seulement si la phrase est vide ou totalement incompréhensible

Règles :
- Si la phrase demande de chercher sur Google ou dans le navigateur, utilise GOOGLE.
- Si c'est une question, une blague, une explication, une conversation, utilise WEB_ASK avec query = la phrase complète.
- N'invente jamais un destinataire, un message ou une heure absents de la phrase : laisse le champ de côté.
- Aujourd'hui, nous sommes : $today.
""".trimIndent()
    }

    /** @return la commande comprise, ou null si Gemini n'a pas pu répondre. */
    fun interpret(phrase: String, key: String): Command? {
        if (key.isBlank() || phrase.isBlank()) return null
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", instructions())))
            )
            .put(
                "contents",
                org.json.JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", org.json.JSONArray().put(JSONObject().put("text", phrase)))
                )
            )
            .put(
                "generationConfig",
                JSONObject().put("responseMimeType", "application/json").put("temperature", 0.1)
                    .put("maxOutputTokens", 1024)
            )
            .toString()
        val raw = Web.request(
            "https://generativelanguage.googleapis.com/v1beta/models/${Config.GEMINI_MODEL}:generateContent",
            body,
            mapOf("x-goog-api-key" to key)
        )
        val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return toCommand(sb.toString(), phrase)
    }

    /** Transforme la réponse JSON de Gemini en commande ; null si elle est inutilisable. */
    internal fun toCommand(text: String, phrase: String): Command? {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        val json = JSONObject(text.substring(start, end + 1))
        val type = try {
            Type.valueOf(json.optString("type").trim().uppercase(Locale.ROOT))
        } catch (e: Exception) {
            return null
        }
        val cmd = Command()
        cmd.type = type
        cmd.raw = phrase
        for (f in FIELDS) {
            if (!json.has(f) || json.isNull(f)) continue
            var v = json.get(f).toString().trim()
            if (v.isEmpty()) continue
            when (f) {
                // Nombres : « 6.0 » devient « 6 »
                "hour", "minute", "seconds", "offset" -> v = v.toDoubleOrNull()?.toInt()?.toString() ?: continue
                // Valeurs fixes : en minuscules
                "app", "state", "dir", "action", "target" -> v = v.lowercase(Locale.ROOT)
                "tomorrow" -> v = if (v.lowercase(Locale.ROOT) in listOf("1", "true", "oui", "demain")) "1" else "0"
            }
            cmd.args[f] = v
        }
        // Sécurité : seules les adresses web sont acceptées pour OPEN_URL
        if (type == Type.OPEN_URL && !cmd.get("url").startsWith("https://") && !cmd.get("url").startsWith("http://")) {
            return null
        }
        if (type == Type.WEB_ASK && !cmd.has("query")) cmd.args["query"] = phrase
        return cmd
    }
}
