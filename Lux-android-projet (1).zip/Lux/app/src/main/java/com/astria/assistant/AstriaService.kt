package com.astria.assistant

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.astria.assistant.CommandParser.Command
import com.astria.assistant.CommandParser.Type

/**
 * Le cœur d'Astria : un service qui écoute le mot « ASTRIA » (reconnaissance vocale hors ligne si
 * disponible), répond « Oui monsieur, que puis-je faire pour vous ? », comprend la demande,
 * demande votre confirmation à la voix, exécute, puis répond à la voix.
 */
class AstriaService : Service() {

    companion object {
        const val ACTION_STOP = "com.astria.assistant.STOP"
        const val ACTION_TRIGGER = "com.astria.assistant.TRIGGER"
        private const val CHANNEL = "astria_listen"
        private const val NOTIF_ID = 7

        @Volatile
        var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var voice: Voice
    private lateinit var actions: Actions
    private var voiceReady = false
    private var pendingTrigger = false
    private var token = 0
    private var busy = false
    private var errorStreak = 0
    private var wakeLock: PowerManager.WakeLock? = null
    private var overlay: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        actions = Actions(applicationContext)
        voice = Voice(this) { ok ->
            voiceReady = ok
            if (ok && running && !busy) {
                if (pendingTrigger) {
                    pendingTrigger = false
                    onWake("")
                } else {
                    wakeLoop()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        startInForeground()
        running = true
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "astria:listen").apply { acquire() }
        }
        if (intent?.action == ACTION_TRIGGER) {
            if (voiceReady && !busy) onWake("") else pendingTrigger = true
        } else if (voiceReady && !busy) {
            wakeLoop()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        token++
        hideOverlay()
        voice.shutdown()
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }

    private fun shutdown() {
        running = false
        token++
        hideOverlay()
        voice.stopAll()
        stopForeground(true)
        stopSelf()
    }

    // ------------------------------------------------------------------ notification

    private fun startInForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Astria à l'écoute", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AstriaService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_astria)
            .setContentTitle("Astria est à l'écoute")
            .setContentText("Dites « Astria » pour m'appeler.")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Arrêter", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ------------------------------------------------------------------ écoute du mot d'éveil

    private fun wakeLoop() {
        if (!running || busy || !voiceReady) return
        val t = token
        voice.listen(
            preferOffline = true,
            onResult = { text ->
                if (t == token && running && !busy) {
                    errorStreak = 0
                    val rest = CommandParser.stripWake(text)
                    if (rest != null) onWake(rest) else wakeLoop()
                }
            },
            onFail = { code ->
                if (t == token && running && !busy) {
                    if (code == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        shutdown()
                    } else {
                        val delay: Long = when (code) {
                            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                                errorStreak = 0
                                150L
                            }
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1500L
                            else -> {
                                errorStreak++
                                minOf(500L * errorStreak, 5000L)
                            }
                        }
                        main.postDelayed({ if (t == token) wakeLoop() }, delay)
                    }
                }
            }
        )
    }

    // ------------------------------------------------------------------ conversation

    private fun onWake(rest: String) {
        busy = true
        token++
        val t = token
        voice.stopAll()
        showOverlay()
        main.postDelayed({
            if (t == token && busy) {
                voice.stopAll()
                endSession()
            }
        }, 120_000L)
        voice.speak(Config.GREETING) {
            if (t == token) {
                if (rest.isNotBlank()) handle(rest, t) else listenCommand(t, 0)
            }
        }
    }

    private fun listenCommand(t: Int, attempt: Int) {
        voice.listen(
            preferOffline = true,
            onResult = { text -> if (t == token) handle(text, t) },
            onFail = {
                if (t == token) {
                    if (attempt < 1) {
                        voice.speak("Je vous écoute, monsieur.") { if (t == token) listenCommand(t, attempt + 1) }
                    } else {
                        say("Je n'ai rien entendu, monsieur.", t)
                    }
                }
            }
        )
    }

    private fun handle(text: String, t: Int) {
        val cmd = CommandParser.parse(text)
        when (cmd.type) {
            Type.UNKNOWN -> askBrain(text, t)
            Type.CANCEL -> say("Très bien, monsieur.", t)
            else -> complete(cmd, t, 0)
        }
    }

    /**
     * Les règles locales n'ont pas compris : si une clé Gemini est enregistrée, Gemini traduit la phrase
     * en commande. Astria demande ensuite votre confirmation comme d'habitude avant d'agir.
     */
    private fun askBrain(text: String, t: Int) {
        val key = Prefs.geminiKey(this)
        if (key.isBlank()) {
            say("Je n'ai pas compris votre demande, monsieur. Ajoutez une clé Gemini dans mes réglages pour que je comprenne mieux.", t)
            return
        }
        Thread {
            var err = ""
            val cmd = try {
                Brain.interpret(text, key)
            } catch (e: Exception) {
                err = e.message ?: ""
                null
            }
            main.post {
                if (t == token) {
                    val code = Regex("HTTP (\\d+)").find(err)?.groupValues?.get(1)
                    when {
                        cmd == null && code == "429" ->
                            say("Gemini est saturé pour le moment, monsieur. Réessayez dans une minute.", t)
                        cmd == null && code != null ->
                            say("Je n'arrive pas à joindre mon cerveau, monsieur. Gemini répond erreur $code.", t)
                        cmd == null ->
                            say("Je n'arrive pas à joindre mon cerveau, monsieur. Vérifiez votre connexion internet.", t)
                        cmd.type == Type.CANCEL -> say("Très bien, monsieur.", t)
                        cmd.type == Type.UNKNOWN -> say("Je n'ai pas compris votre demande, monsieur.", t)
                        else -> complete(cmd, t, 0)
                    }
                }
            }
        }.start()
    }

    /** Demande les informations manquantes, vérifie le verrouillage, puis demande confirmation. */
    private fun complete(cmd: Command, t: Int, asked: Int) {
        val field = cmd.missing()
        if (field != null) {
            if (asked >= 2) {
                say("Il me manque des informations, monsieur. J'annule.", t)
                return
            }
            voice.speak(question(field, cmd)) {
                if (t == token) {
                    voice.listen(
                        preferOffline = true,
                        onResult = { answer ->
                            if (t == token) {
                                if (CommandParser.parse(answer).type == Type.CANCEL) {
                                    say("Très bien, monsieur.", t)
                                } else {
                                    CommandParser.fillField(cmd, field, answer)
                                    complete(cmd, t, asked + 1)
                                }
                            }
                        },
                        onFail = { if (t == token) say("Je n'ai rien entendu, monsieur.", t) }
                    )
                }
            }
            return
        }
        if (Prefs.requireUnlock(this) && actions.isSensitive(cmd) && isLocked()) {
            say("Veuillez d'abord déverrouiller votre téléphone, monsieur.", t)
            return
        }
        if (Prefs.confirmEvery(this)) confirm(cmd, t, 0) else run(cmd, t)
    }

    private fun question(field: String, cmd: Command): String = when (field) {
        "recipient" -> when (cmd.type) {
            Type.CALL -> "Qui dois-je appeler, monsieur ?"
            Type.CONTACT_INFO -> "De qui souhaitez-vous le numéro, monsieur ?"
            else -> "À qui dois-je l'envoyer, monsieur ?"
        }
        "message" -> "Que dois-je écrire, monsieur ?"
        "time" -> "À quelle heure, monsieur ?"
        "duration" -> "Pour combien de temps, monsieur ?"
        "name" -> if (cmd.type == Type.OPEN_URL) "Quel site, monsieur ?" else "Quelle application, monsieur ?"
        "query" -> "Que dois-je chercher, monsieur ?"
        else -> "Pouvez-vous préciser, monsieur ?"
    }

    private fun confirm(cmd: Command, t: Int, attempt: Int) {
        val prompt = if (attempt == 0) {
            "Je vais ${actions.describe(cmd)}. Confirmez-vous, monsieur ?"
        } else {
            "Pardon, monsieur. Dites oui ou non."
        }
        val retry = {
            if (t == token) {
                if (attempt < 1) confirm(cmd, t, 1) else say("Je n'ai pas de confirmation, j'annule, monsieur.", t)
            }
        }
        voice.speak(prompt) {
            if (t == token) {
                voice.listen(
                    preferOffline = true,
                    onResult = { answer ->
                        if (t == token) {
                            when (CommandParser.yesNo(answer)) {
                                true -> run(cmd, t)
                                false -> say("Très bien, monsieur, j'annule.", t)
                                null -> retry()
                            }
                        }
                    },
                    onFail = { retry() }
                )
            }
        }
    }

    private fun run(cmd: Command, t: Int) {
        actions.execute(cmd) { message -> if (t == token) say(message, t) }
    }

    /** Astria dit [message] puis retourne à l'écoute du mot d'éveil. */
    private fun say(message: String, t: Int) {
        voice.speak(message) { if (t == token) endSession() }
    }

    private fun endSession() {
        busy = false
        token++
        hideOverlay()
        main.postDelayed({ wakeLoop() }, 400)
    }

    private fun isLocked(): Boolean {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isKeyguardLocked
    }

    // ------------------------------------------------------------------ fenêtre invisible
    // Android limite l'ouverture d'applications depuis l'arrière-plan. Avec l'autorisation
    // « Afficher par-dessus les autres applis », Astria affiche une fenêtre d'un pixel pendant
    // qu'elle travaille, ce qui lui permet d'ouvrir WhatsApp, l'alarme, etc.

    private fun showOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        try {
            val v = View(this)
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(v, lp)
            overlay = v
        } catch (e: Exception) {
            overlay = null
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        overlay = null
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Exception) {
        }
    }
}
