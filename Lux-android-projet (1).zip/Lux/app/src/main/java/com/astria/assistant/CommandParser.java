package com.astria.assistant;

import java.net.URLEncoder;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Comprend les phrases françaises SANS internet (règles locales, aucune IA externe).
 * Classe volontairement sans dépendance Android : elle est testée séparément.
 */
public final class CommandParser {
    private CommandParser() {}

    public enum Type {
        UNKNOWN, CANCEL, TIME, DATE, BATTERY, WEATHER, ALARM, TIMER, CALL, SMS, SOCIAL,
        READ_SMS, CONTACT_INFO, CAL_READ, CAL_ADD, OPEN_APP, OPEN_URL, WEB_ASK, GOOGLE,
        FLASHLIGHT, VOLUME, NAV, SETTINGS
    }

    public static final class Command {
        public Type type = Type.UNKNOWN;
        public final Map<String, String> args = new HashMap<String, String>();
        public String raw = "";

        public String get(String k) {
            String v = args.get(k);
            return v == null ? "" : v;
        }

        public boolean has(String k) {
            return !get(k).isEmpty();
        }

        public int geti(String k, int def) {
            try {
                return Integer.parseInt(get(k));
            } catch (Exception e) {
                return def;
            }
        }

        /** Nom du champ manquant à demander à l'utilisateur, ou null si la commande est complète. */
        public String missing() {
            switch (type) {
                case CALL:
                case CONTACT_INFO:
                    return has("recipient") || has("name") ? null : "recipient";
                case SMS:
                case SOCIAL:
                    if (!has("recipient")) return "recipient";
                    if (!has("message")) return "message";
                    return null;
                case ALARM:
                    return has("hour") ? null : "time";
                case CAL_ADD:
                    return has("hour") ? null : "time";
                case TIMER:
                    return geti("seconds", 0) > 0 ? null : "duration";
                case OPEN_APP:
                    return has("name") ? null : "name";
                case OPEN_URL:
                    return has("url") ? null : "name";
                case WEB_ASK:
                case GOOGLE:
                    return has("query") ? null : "query";
                default:
                    return null;
            }
        }
    }

    /** Pour les tests : date « maintenant » imposée. */
    public static Calendar nowOverride = null;

    private static Calendar now() {
        return nowOverride != null ? (Calendar) nowOverride.clone() : Calendar.getInstance();
    }

    // ------------------------------------------------------------------ utilitaires

    /** Minuscules, sans accents, ponctuation simplifiée. Garde exactement la même longueur. */
    static String norm(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '’' || c == '‘' || c == '`') c = '\'';
            if (c == 'œ' || c == 'Œ') c = 'o';
            String d = Normalizer.normalize(String.valueOf(c), Normalizer.Form.NFD);
            char b = Character.toLowerCase(d.charAt(0));
            if (b == '-' || b == '?' || b == '!' || b == ';' || b == ',' || b == '«'
                    || b == '»' || b == '"') b = ' ';
            sb.append(b);
        }
        return sb.toString();
    }

    private static Matcher m(String regex, String n) {
        return Pattern.compile(regex).matcher(n);
    }

    private static boolean has(String regex, String n) {
        return m(regex, n).find();
    }

    private static String cleanName(String s) {
        String r = s.trim();
        r = r.replaceAll("(?iu)\\s*(?:s'il (?:te|vous) pla[iî]t|merci|maintenant|stp|svp)\\s*$", "");
        String prev;
        do {
            prev = r;
            r = r.replaceAll("(?iu)^(?:le |la |l'|mon |ma |mes |monsieur |madame |a |au |aux )", "").trim();
        } while (!r.equals(prev));
        r = r.replaceAll("[\\s.,:;!?]+$", "");
        return r.trim();
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase(Locale.FRENCH) + s.substring(1);
    }

    private static final Map<String, Integer> WORDS = new HashMap<String, Integer>();

    static {
        String[] w = {"zero", "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix",
                "onze", "douze", "treize", "quatorze", "quinze", "seize"};
        for (int i = 0; i < w.length; i++) WORDS.put(w[i], i);
        WORDS.put("une", 1);
        WORDS.put("dix sept", 17);
        WORDS.put("dix huit", 18);
        WORDS.put("dix neuf", 19);
        WORDS.put("vingt", 20);
        WORDS.put("vingt et un", 21);
        WORDS.put("vingt et une", 21);
        WORDS.put("vingt deux", 22);
        WORDS.put("vingt trois", 23);
        WORDS.put("trente", 30);
        WORDS.put("quarante", 40);
        WORDS.put("cinquante", 50);
        WORDS.put("soixante", 60);
    }

    private static int num(String s) {
        try {
            return Integer.parseInt(s);
        } catch (Exception e) {
            Integer v = WORDS.get(s);
            return v == null ? 0 : v;
        }
    }

    // ------------------------------------------------------------------ analyse principale

    public static Command parse(String raw) {
        Command c = new Command();
        c.raw = raw == null ? "" : raw.trim();
        String orig = c.raw;
        String n = norm(orig);
        if (n.trim().isEmpty()) return c;

        if (has("^\\s*(?:non\\s+)?(?:annule|annuler|laisse tomber|oublie ca|oublie|stop|arrete|rien|c'est bon)\\s*$", n)) {
            c.type = Type.CANCEL;
            return c;
        }

        if (parseSend(c, orig, n)) return c;

        if (has("\\b(?:lis|lire|lit|ecoute|ecouter|verifie|regarde|consulte)\\b.*\\b(?:messages?|sms|texto|messagerie)\\b", n)
                || has("\\b(?:nouveaux?|derniers?)\\s+(?:messages?|sms)\\b", n)
                || has("\\bai je (?:recu )?(?:des |de )?(?:nouveaux )?(?:messages?|sms)\\b", n)) {
            c.type = Type.READ_SMS;
            return c;
        }

        // Appels
        Matcher mc = m("\\b(?:appelle|appeler|compose|contacte|contacter)\\b\\s*(?:a |au )?", n);
        Matcher mc2 = m("\\b(?:passe un appel|passer un appel|telephone|telephoner)\\s+(?:a |au )", n);
        Matcher hit = mc.find() ? mc : (mc2.find() ? mc2 : null);
        if (hit != null) {
            c.type = Type.CALL;
            String who = cleanName(orig.substring(hit.end()));
            if (!who.isEmpty()) c.args.put("recipient", who);
            return c;
        }

        // Minuteur (avant alarme : « réveille-moi dans 20 minutes »)
        boolean timerWord = has("\\b(?:minuteur|minuterie|compte a rebours|chronometre|chrono)\\b", n);
        boolean remind = has("\\b(?:previens moi|prevenez moi|rappelle moi|reveille moi|alerte moi|sonne)\\b", n)
                && has("\\bdans\\b", n) && parseDuration(n) > 0;
        boolean alarmInDuration = has("\\b(?:alarme|reveil)\\b", n) && has("\\bdans\\b", n) && parseDuration(n) > 0;
        if (timerWord || remind || alarmInDuration) {
            c.type = Type.TIMER;
            int s = parseDuration(n);
            if (s > 0) c.args.put("seconds", String.valueOf(s));
            return c;
        }

        // Alarme
        if (has("\\b(?:alarme|reveil|reveille moi|reveillez moi)\\b", n)) {
            c.type = Type.ALARM;
            int[] t = parseTime(n);
            if (t != null) {
                c.args.put("hour", String.valueOf(t[0]));
                c.args.put("minute", String.valueOf(t[1]));
            }
            return c;
        }

        // Agenda : ajout puis lecture
        boolean calNoun = has("\\b(?:evenements?|rendez vous|rdv|reunions?|agenda|calendrier)\\b", n);
        if (calNoun && has("\\b(?:ajoute|ajouter|cree|creer|programme|programmer|planifie|planifier|note|noter|enregistre|enregistrer|fixe|fixer|mets|mettre|inscris|inscrire)\\b", n)) {
            parseCalAdd(c, orig, n);
            return c;
        }
        if (has("\\b(?:agenda|calendrier|rendez vous|rdv|planning|programme|evenements?|reunions?)\\b", n)
                && has("\\b(?:aujourd'hui|demain|ai je|j'ai|quels?|quelles?|qu'est ce|mes|mon|prochains?|cette semaine|ce soir|ce matin)\\b", n)) {
            c.type = Type.CAL_READ;
            c.args.put("offset", has("\\bapres demain\\b", n) ? "2" : (has("\\bdemain\\b", n) ? "1" : "0"));
            return c;
        }

        // Info contact
        Matcher mn = m("\\b(?:numero|telephone|contact|coordonnees)\\s+(?:de |du |d')\\s*", n);
        if (mn.find() && !has("\\b(?:appelle|envoie|ecris)\\b", n)) {
            c.type = Type.CONTACT_INFO;
            String who = cleanName(orig.substring(mn.end()));
            if (!who.isEmpty()) c.args.put("name", who);
            return c;
        }

        // Navigation du téléphone (service d'accessibilité)
        String nav = null;
        if (has("\\b(?:ecran d'accueil|page d'accueil|accueil|home)\\b", n)) nav = "home";
        else if (has("\\b(?:capture d'ecran|screenshot|capture l'ecran|capture ecran)\\b", n)) nav = "screenshot";
        else if (has("\\b(?:applications? recentes?|apps? recentes?|multitache|recents)\\b", n)) nav = "recents";
        else if (has("\\b(?:verrouille|verrouiller|bloque l'ecran|bloquer l'ecran|eteins l'ecran|eteindre l'ecran)\\b", n)) nav = "lock";
        else if (has("\\b(?:notifications?|panneau de notification)\\b", n)) nav = "notifs";
        else if (has("^\\s*(?:fais |fait )?(?:retour|reviens en arriere|retourne en arriere|precedent|reviens)\\s*$", n)) nav = "back";
        if (nav != null) {
            c.type = Type.NAV;
            c.args.put("action", nav);
            return c;
        }

        // Réglages
        if (has("\\b(?:parametres?|reglages|configuration|wi ?fi|bluetooth|donnees mobiles|mode avion|ne pas deranger|luminosite)\\b", n)) {
            c.type = Type.SETTINGS;
            String target = "general";
            if (has("\\bwi ?fi\\b", n)) target = "wifi";
            else if (has("\\bbluetooth\\b", n)) target = "bluetooth";
            else if (has("\\bdonnees mobiles\\b", n)) target = "data";
            else if (has("\\bmode avion\\b", n)) target = "airplane";
            else if (has("\\bluminosite\\b", n)) target = "display";
            c.args.put("target", target);
            return c;
        }

        // Lampe torche
        if (has("\\b(?:lampe torche|torche|lampe de poche|flash|lampe)\\b", n)) {
            c.type = Type.FLASHLIGHT;
            c.args.put("state", has("\\b(?:eteins|eteint|eteindre|ferme|desactive|desactiver|coupe|arrete)\\b", n) ? "off" : "on");
            return c;
        }

        // Volume
        if (has("\\b(?:volume|le son|sonnerie)\\b", n)) {
            String dir = null;
            if (has("\\b(?:maximum|a fond|max)\\b", n)) dir = "max";
            else if (has("\\b(?:coupe|couper|mute|muet|silence)\\b", n)) dir = "mute";
            else if (has("\\b(?:baisse|baisser|diminue|diminuer|moins fort|plus bas|moins)\\b", n)) dir = "down";
            else if (has("\\b(?:monte|monter|augmente|augmenter|plus fort|plus haut|fort)\\b", n)) dir = "up";
            if (dir != null) {
                c.type = Type.VOLUME;
                c.args.put("dir", dir);
                return c;
            }
        }

        // Météo
        if (has("\\b(?:meteo|quel temps|temperature|pleuvoir|pleut|pluie|il fait chaud|il fait froid|soleil)\\b", n)) {
            c.type = Type.WEATHER;
            c.args.put("tomorrow", has("\\bdemain\\b", n) ? "1" : "0");
            Matcher mcity = m("\\b(?:a|de|pour|sur|dans|au|en)\\s+(?!demain|aujourd|ce |cette |la |le |les |l')([a-z' ]+?)(?:\\s+(?:demain|aujourd'hui|ce soir|ce matin|cet apres midi))?\\s*$", n);
            if (mcity.find()) {
                String city = cleanName(orig.substring(mcity.start(1), mcity.end(1)));
                if (!city.isEmpty()) c.args.put("city", city);
            }
            return c;
        }

        if (has("\\b(?:batterie|niveau de charge|charge du telephone|pourcentage)\\b", n)) {
            c.type = Type.BATTERY;
            return c;
        }
        if (has("\\b(?:quel jour|quelle date|la date|date d'aujourd'hui|jour sommes nous|on est le combien|combien on est)\\b", n)) {
            c.type = Type.DATE;
            return c;
        }
        if (has("\\b(?:quelle heure|l'heure|heure est il|heure qu'il est)\\b", n)) {
            c.type = Type.TIME;
            return c;
        }

        // Ouvrir une application ou un site
        Matcher mo = m("\\b(?:ouvre|ouvrir|lance|lancer|demarre|demarrer|va sur|aller sur|affiche|montre moi)\\b\\s*", n);
        if (mo.find()) {
            String rest = orig.substring(mo.end()).trim();
            String prev;
            do {
                prev = rest;
                rest = rest.replaceFirst("(?iu)^(?:l'application |l'appli |l'app |l'|le |la |les |application |appli |app |site web |site |page |du |de )", "").trim();
            } while (!rest.equals(prev));
            rest = rest.replaceAll("(?iu)\\s*(?:s'il (?:te|vous) pla[iî]t|stp|svp)\\s*$", "").trim();
            String rl = rest.toLowerCase(Locale.ROOT);
            boolean siteWord = has("\\b(?:site|page web|internet|navigateur web)\\b", n);
            String dotted = rl.replaceAll("\\s+point\\s+", ".").replaceAll("\\s+", "");
            if (dotted.matches(".*\\.(?:com|org|net|fr|cd|io|info|co|app|tv|be|ca|edu|gov)(?:/.*)?")
                    || dotted.startsWith("www.") || dotted.startsWith("http")) {
                String url = dotted.startsWith("http") ? dotted : "https://" + dotted;
                c.type = Type.OPEN_URL;
                c.args.put("url", url);
                return c;
            }
            if (siteWord && !rest.isEmpty() && !has("\\b(?:internet|navigateur)\\b", rl)) {
                c.type = Type.OPEN_URL;
                try {
                    c.args.put("url", "https://www.google.com/search?q=" + URLEncoder.encode(rest, "UTF-8"));
                } catch (Exception e) {
                    c.args.put("url", "https://www.google.com");
                }
                return c;
            }
            if (rl.equals("internet") || rl.equals("le web") || rl.equals("web") || rl.equals("navigateur")) {
                c.type = Type.OPEN_URL;
                c.args.put("url", "https://www.google.com");
                return c;
            }
            c.type = Type.OPEN_APP;
            if (!rest.isEmpty()) c.args.put("name", rest);
            return c;
        }

        // Recherche web
        Matcher mq = m("\\b(?:cherche|chercher|recherche|rechercher|trouve|trouver|renseigne moi sur|informe moi sur|google)\\b\\s*", n);
        if (mq.find()) {
            String q = orig.substring(mq.end()).trim();
            String prev;
            do {
                prev = q;
                q = q.replaceFirst("(?iu)^(?:moi |des |de |les |la |le |l'|un |une |informations? sur |infos? sur |sur |a propos de |à propos de |concernant )", "").trim();
            } while (!q.equals(prev));
            q = q.replaceAll("(?iu)\\s+(?:sur (?:internet|le web|google|le net)|en ligne)\\s*$", "").trim();
            // « fais une recherche pour moi sur Google » : on retire les mots de remplissage
            boolean viaGoogle = has("\\b(?:google|chrome|navigateur|moteur de recherche)\\b", n);
            q = q.replaceFirst("(?iu)^(?:pour moi|moi)\\s+", "").trim();
            q = q.replaceFirst("(?iu)^(?:sur |dans |avec |via )?(?:google|chrome|le navigateur|navigateur|le moteur de recherche)\\b[\\s,:]*(?:pour |de |des |du |les |la |le |l')?", "").trim();
            q = q.replaceFirst("(?iu)^(?:pour moi|moi|quelque chose|une chose)$", "").trim();
            if (viaGoogle) {
                // Sur Google : on ouvre vraiment la recherche dans le navigateur
                c.type = Type.GOOGLE;
                if (!q.isEmpty()) c.args.put("query", q);
                return c;
            }
            c.type = Type.WEB_ASK;
            if (!q.isEmpty()) c.args.put("query", q);
            return c;
        }
        if (has("^\\s*(?:dis moi |peux tu me dire |pourrais tu me dire |tu sais )?(?:qui|que|quoi|quel|quelle|quels|quelles|quand|ou|comment|pourquoi|combien|c'est quoi|qu'est ce|explique|definis|definition)\\b", n)) {
            c.type = Type.WEB_ASK;
            c.args.put("query", orig);
            return c;
        }

        return c;
    }

    // ------------------------------------------------------------------ envoi de messages

    private static final String MSG_SEP =
            "\\b(?:que|qu'|disant|pour dire|pour lui dire|en lui disant|lui disant|qui dit|qui lui dit|avec le message|le message)\\b\\s*|\\s*:\\s*";

    private static boolean parseSend(Command c, String orig, String n) {
        Matcher mv = m("\\b(?:envoie|envoyer|envoi|ecris|ecrire|redige|rediger|poste|poster|transmets|transmettre|dis)\\b", n);
        if (!mv.find()) return false;
        boolean verbOk = has("\\b(?:envoie|envoyer|envoi|ecris|ecrire|redige|rediger|poste|poster|transmets|transmettre)\\b", n)
                || has("\\bdis (?:a|au|lui) ", n);
        if (!verbOk) return false;
        if (has("\\b(?:envoie|envoyer|envoi|transmets) moi\\b", n)) return false;

        String app = null;
        if (has("\\bwhats ?app\\b", n)) app = "whatsapp";
        else if (has("\\btelegram\\b", n)) app = "telegram";
        else if (has("\\bmessenger\\b", n)) app = "messenger";
        else if (has("\\b(?:instagram|insta)\\b", n)) app = "instagram";
        else if (has("\\bfacebook\\b", n)) app = "facebook";
        else if (has("\\b(?:twitter|tweet)\\b", n) || has("\\bsur x\\b", n)) app = "x";
        else if (has("\\blinkedin\\b", n)) app = "linkedin";

        boolean mentionsMsg = app != null || has("\\b(?:sms|texto|messages?|messagerie)\\b", n);
        if (!mentionsMsg && !has("\\b(?:a|au) \\S", n)) return false;

        int vstart = mv.start();
        String recipient = "";
        String message = "";
        Matcher ma = m("\\b(?:a|au|aux|pour(?! (?:lui )?dire)|vers)\\s+", n);
        if (ma.find(vstart)) {
            int rs = ma.end();
            Matcher sep = m("\\b(?:que|qu'|disant|pour dire|pour lui dire|en lui disant|lui disant|qui dit|qui lui dit|avec le message|le message|sur|par|via)\\b\\s*|\\s*:\\s*", n);
            int re = n.length();
            int ms = -1;
            if (sep.find(rs)) {
                re = sep.start();
                String sw = sep.group().trim();
                if (sw.equals("sur") || sw.equals("par") || sw.equals("via")) {
                    Matcher sep2 = m(MSG_SEP, n);
                    if (sep2.find(sep.end())) ms = sep2.end();
                } else {
                    ms = sep.end();
                }
            }
            recipient = cleanName(orig.substring(rs, Math.max(rs, re)));
            if (ms >= 0 && ms <= orig.length()) message = orig.substring(ms).trim();
        } else {
            Matcher sep = m(MSG_SEP, n);
            if (sep.find(vstart)) message = orig.substring(sep.end()).trim();
        }
        message = message.replaceAll("^[\"«»\\s]+|[\"«»\\s]+$", "");
        message = message.replaceFirst("(?iu)^(?:que |qu')\\s*", "");
        if (!message.isEmpty()) message = capitalize(message);

        c.type = app == null ? Type.SMS : Type.SOCIAL;
        if (app != null) c.args.put("app", app);
        if (!recipient.isEmpty()) c.args.put("recipient", recipient);
        if (!message.isEmpty()) c.args.put("message", message);
        return true;
    }

    // ------------------------------------------------------------------ agenda

    private static void parseCalAdd(Command c, String orig, String n) {
        c.type = Type.CAL_ADD;
        int[] t = parseTime(n);
        if (t != null) {
            c.args.put("hour", String.valueOf(t[0]));
            c.args.put("minute", String.valueOf(t[1]));
        }
        Calendar d = parseDate(n);
        if (d == null && t != null) {
            d = now();
            d.set(Calendar.SECOND, 0);
            d.set(Calendar.MILLISECOND, 0);
            d.set(Calendar.HOUR_OF_DAY, 0);
            d.set(Calendar.MINUTE, 0);
            Calendar probe = now();
            probe.set(Calendar.HOUR_OF_DAY, t[0]);
            probe.set(Calendar.MINUTE, t[1]);
            if (probe.before(now())) d.add(Calendar.DAY_OF_MONTH, 1);
        }
        if (d != null) c.args.put("date", isoDate(d));

        String kind = "Événement";
        Matcher mk = m("\\b(?:evenement|rendez vous|rdv|reunion)\\b", n);
        int from;
        if (mk.find()) {
            String k = mk.group();
            kind = k.startsWith("rendez") || k.equals("rdv") ? "Rendez-vous" : (k.equals("reunion") ? "Réunion" : "Événement");
            from = mk.end();
        } else {
            Matcher ma = m("\\b(?:agenda|calendrier)\\b", n);
            from = ma.find() ? ma.end() : 0;
        }
        String rest = orig.substring(from);
        String nr = n.substring(from);
        rest = removeMatches(rest, nr, new String[]{
                "\\b(?:a |vers |pour |de )?\\d{1,2}\\s*(?:heures?|h|:)\\s*\\d{0,2}(?: et demie?| et quart| moins le quart)?(?: du matin| de l'apres midi| du soir)?",
                "\\b(?:a |vers )?(?:midi|minuit)\\b",
                "\\b(?:a |vers )?(?:une?|deux|trois|quatre|cinq|six|sept|huit|neuf|dix|onze|douze|treize|quatorze|quinze|seize|dix sept|dix huit|dix neuf|vingt|vingt et une?|vingt deux|vingt trois) heures?(?: et demie?| et quart| moins le quart)?(?: du matin| de l'apres midi| du soir)?",
                "\\b(?:aujourd'hui|apres demain|demain|ce soir|ce matin|cet apres midi)\\b",
                "\\b(?:lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche)\\b",
                "\\ble\\s+\\d{1,2}(?:er)?(?:\\s+(?:janvier|fevrier|mars|avril|mai|juin|juillet|aout|septembre|octobre|novembre|decembre))?\\b",
                "\\b(?:dans mon|dans l'|dans le|sur mon|sur le|a mon|a l'|a|mon|l'|le|la|un|une)\\s*(?:agenda|calendrier)\\b"
        });
        rest = rest.replaceFirst("(?iu)^[\\s:,.]*(?:intitule|intitulee|appele|appelee|nomme|nommee|pour|sur|dans|a|un|une|le|la|l')\\s+", "").trim();
        rest = rest.replaceAll("[\\s.,:;!?]+$", "").trim();
        String title;
        if (rest.isEmpty()) {
            title = kind;
        } else if (rest.toLowerCase(Locale.ROOT).matches("^(?:avec|de|du|d'|des|au|chez|a)\\b.*")
                || rest.toLowerCase(Locale.ROOT).startsWith("d'")) {
            title = kind + " " + rest;
        } else {
            title = capitalize(rest);
        }
        c.args.put("title", title);
    }

    private static String removeMatches(String orig, String n, String[] regexes) {
        boolean[] cut = new boolean[orig.length()];
        for (String rx : regexes) {
            Matcher mm = Pattern.compile(rx).matcher(n);
            while (mm.find()) {
                for (int i = mm.start(); i < mm.end() && i < cut.length; i++) cut[i] = true;
            }
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < orig.length(); i++) if (!cut[i]) sb.append(orig.charAt(i));
        return sb.toString().replaceAll("\\s+", " ").trim();
    }

    private static String isoDate(Calendar d) {
        return String.format(Locale.US, "%04d-%02d-%02d", d.get(Calendar.YEAR), d.get(Calendar.MONTH) + 1,
                d.get(Calendar.DAY_OF_MONTH));
    }

    static Calendar parseDate(String n) {
        Calendar t = now();
        t.set(Calendar.HOUR_OF_DAY, 0);
        t.set(Calendar.MINUTE, 0);
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (has("\\bapres demain\\b", n)) {
            t.add(Calendar.DAY_OF_MONTH, 2);
            return t;
        }
        if (has("\\bdemain\\b", n)) {
            t.add(Calendar.DAY_OF_MONTH, 1);
            return t;
        }
        if (has("\\b(?:aujourd'hui|ce soir|ce matin|cet apres midi)\\b", n)) return t;

        String[] days = {"dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"};
        for (int i = 0; i < days.length; i++) {
            if (has("\\b" + days[i] + "\\b", n)) {
                int target = i + 1; // Calendar.SUNDAY == 1
                int diff = (target - t.get(Calendar.DAY_OF_WEEK) + 7) % 7;
                if (diff == 0) diff = 7;
                t.add(Calendar.DAY_OF_MONTH, diff);
                return t;
            }
        }
        Matcher md = m("\\ble\\s+(\\d{1,2})(?:er)?(?:\\s+(janvier|fevrier|mars|avril|mai|juin|juillet|aout|septembre|octobre|novembre|decembre))?\\b", n);
        if (md.find()) {
            int day = Integer.parseInt(md.group(1));
            if (day < 1 || day > 31) return null;
            String[] months = {"janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout",
                    "septembre", "octobre", "novembre", "decembre"};
            if (md.group(2) != null) {
                for (int i = 0; i < 12; i++) {
                    if (months[i].equals(md.group(2))) t.set(Calendar.MONTH, i);
                }
                t.set(Calendar.DAY_OF_MONTH, day);
                if (t.before(now())) t.add(Calendar.YEAR, 1);
            } else {
                t.set(Calendar.DAY_OF_MONTH, 1);
                if (day < now().get(Calendar.DAY_OF_MONTH)) t.add(Calendar.MONTH, 1);
                t.set(Calendar.DAY_OF_MONTH, Math.min(day, t.getActualMaximum(Calendar.DAY_OF_MONTH)));
            }
            return t;
        }
        return null;
    }

    // ------------------------------------------------------------------ heure et durée

    /** @return {heure, minute} ou null. */
    static int[] parseTime(String n) {
        int h = -1;
        int min = 0;
        int end = -1;
        Matcher m1 = m("(\\d{1,2})\\s*(?:heures?|h|:)\\s*(\\d{1,2})?", n);
        if (m1.find()) {
            h = Integer.parseInt(m1.group(1));
            if (m1.group(2) != null && !m1.group(2).isEmpty()) min = Integer.parseInt(m1.group(2));
            end = m1.end();
        } else {
            Matcher mw = m("\\b(dix sept|dix huit|dix neuf|vingt et une|vingt et un|vingt deux|vingt trois|zero|une|un|deux|trois|quatre|cinq|six|sept|huit|neuf|dix|onze|douze|treize|quatorze|quinze|seize|vingt)\\s+heures?\\b", n);
            if (mw.find()) {
                h = num(mw.group(1));
                end = mw.end();
            } else {
                Matcher mm = m("\\b(midi|minuit)\\b", n);
                if (mm.find()) {
                    h = mm.group(1).equals("midi") ? 12 : 0;
                    end = mm.end();
                }
            }
        }
        if (h < 0) return null;
        String tail = n.substring(end);
        if (has("^\\s*et demie?\\b", tail)) min = 30;
        else if (has("^\\s*et quart\\b", tail)) min = 15;
        else if (has("^\\s*moins le quart\\b", tail)) {
            h -= 1;
            min = 45;
            if (h < 0) h = 23;
        }
        if (h < 12 && has("\\b(?:de l'apres midi|du soir)\\b", n)) h += 12;
        if (h > 23 || min > 59) return null;
        return new int[]{h, min};
    }

    /** Durée en secondes (0 si aucune). */
    static int parseDuration(String n) {
        int total = 0;
        if (has("\\bdemi heure\\b", n)) total += 1800;
        if (has("\\bquart d'heure\\b", n)) total += 900;
        Matcher mm = m("\\b(\\d+|une?|deux|trois|quatre|cinq|six|sept|huit|neuf|dix|quinze|vingt|trente|quarante|cinquante|soixante)\\s*(heures?|h|minutes?|mins?|mn|secondes?|secs?|s)\\b", n);
        while (mm.find()) {
            int v = num(mm.group(1));
            String u = mm.group(2);
            if (u.startsWith("h")) total += v * 3600;
            else if (u.startsWith("m")) total += v * 60;
            else total += v;
        }
        if (has("\\bheures? et demie?\\b", n)) total += 1800;
        if (has("\\bheures? et quart\\b", n)) total += 900;
        return total;
    }

    /** Applique la réponse de l'utilisateur à un champ manquant. */
    public static void fillField(Command c, String field, String answer) {
        String a = answer == null ? "" : answer.trim();
        String n = norm(a);
        if ("time".equals(field)) {
            int[] t = parseTime(n);
            if (t != null) {
                c.args.put("hour", String.valueOf(t[0]));
                c.args.put("minute", String.valueOf(t[1]));
            }
            if (c.type == Type.CAL_ADD && !c.has("date") && c.has("hour")) {
                Calendar d = parseDate(n);
                if (d == null) {
                    d = now();
                    d.set(Calendar.HOUR_OF_DAY, 0);
                    d.set(Calendar.MINUTE, 0);
                    Calendar probe = now();
                    probe.set(Calendar.HOUR_OF_DAY, c.geti("hour", 0));
                    probe.set(Calendar.MINUTE, c.geti("minute", 0));
                    if (probe.before(now())) d.add(Calendar.DAY_OF_MONTH, 1);
                }
                c.args.put("date", isoDate(d));
            }
        } else if ("duration".equals(field)) {
            int s = parseDuration(n);
            if (s > 0) c.args.put("seconds", String.valueOf(s));
        } else if ("recipient".equals(field)) {
            String r = cleanName(a);
            if (!r.isEmpty()) c.args.put(c.type == Type.CONTACT_INFO ? "name" : "recipient", r);
        } else if ("message".equals(field)) {
            if (!a.isEmpty()) c.args.put("message", capitalize(a));
        } else if ("name".equals(field)) {
            if (c.type == Type.OPEN_URL) {
                String d = a.toLowerCase(Locale.ROOT).replaceAll("\\s+point\\s+", ".").replaceAll("\\s+", "");
                c.args.put("url", d.startsWith("http") ? d : "https://" + d);
            } else if (!a.isEmpty()) {
                c.args.put("name", a);
            }
        } else if ("query".equals(field)) {
            if (!a.isEmpty()) c.args.put("query", a);
        }
    }

    // ------------------------------------------------------------------ oui / non

    /** true = oui, false = non, null = pas clair. */
    public static Boolean yesNo(String raw) {
        String s = " " + norm(raw == null ? "" : raw).replaceAll("[^a-z' ]", " ") + " ";
        String[] no = {" non ", " annule ", " annuler ", " stop ", " arrete ", " pas ", " laisse tomber ", " jamais ", " refuse "};
        String[] yes = {" oui ", " ouais ", " ok ", " okay ", " d'accord ", " confirme ", " confirmer ", " vas y ", " go ",
                " exact ", " c'est bon ", " parfait ", " envoie ", " lance ", " affirmatif ", " bien sur ", " volontiers ",
                " certainement ", " tout a fait "};
        for (String x : no) if (s.contains(x)) return Boolean.FALSE;
        for (String x : yes) if (s.contains(x)) return Boolean.TRUE;
        return null;
    }

    // ------------------------------------------------------------------ mot d'éveil

    private static final String[] WAKE_WORDS = {"astria", "asteria", "astrea", "astrya", "astrie", "astriah", "astryah", "astriya"};

    private static boolean isWake(String w) {
        if (w.startsWith("h") && w.length() > 5) w = w.substring(1);
        for (String x : WAKE_WORDS) if (x.equals(w)) return true;
        return w.length() >= 5 && w.length() <= 7 && lev(w, "astria") <= 1;
    }

    private static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] tmp = prev;
            prev = cur;
            cur = tmp;
        }
        return prev[b.length()];
    }

    /**
     * Cherche « Astria » dans les 3 premiers mots.
     * @return le reste de la phrase (peut être vide) ou null si le mot d'éveil est absent.
     */
    public static String stripWake(String raw) {
        if (raw == null) return null;
        String n = norm(raw);
        Matcher t = Pattern.compile("[a-z0-9']+").matcher(n);
        List<int[]> pos = new ArrayList<int[]>();
        List<String> words = new ArrayList<String>();
        while (t.find()) {
            pos.add(new int[]{t.start(), t.end()});
            words.add(t.group());
        }
        for (int i = 0; i < Math.min(words.size(), 3); i++) {
            if (isWake(words.get(i))) return tail(raw, pos.get(i)[1]);
            if (i + 1 < words.size() && words.get(i).length() <= 3 && isWake(words.get(i) + words.get(i + 1))) {
                return tail(raw, pos.get(i + 1)[1]);
            }
        }
        return null;
    }

    private static String tail(String raw, int end) {
        return raw.substring(Math.min(end, raw.length())).replaceFirst("^[\\s,.:;!?\\-]+", "").trim();
    }
}
