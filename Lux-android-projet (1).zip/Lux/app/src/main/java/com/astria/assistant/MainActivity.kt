package com.astria.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

/**
 * Écran de configuration d'Astria. Astria ne répond QUE par la voix : cet écran sert seulement
 * à l'activer, à lui donner les autorisations et à régler la ville et la clé Gemini (facultative).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var toggle: MaterialButton
    private lateinit var talk: MaterialButton
    private lateinit var btnPerms: MaterialButton
    private lateinit var btnOverlay: MaterialButton
    private lateinit var btnAccess: MaterialButton
    private lateinit var btnBattery: MaterialButton
    private val main = Handler(Looper.getMainLooper())

    private fun neededPermissions(): Array<String> {
        val list = arrayListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        return list.toTypedArray()
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        toggle = findViewById(R.id.btn_toggle)
        talk = findViewById(R.id.btn_talk)
        btnPerms = findViewById(R.id.btn_perms)
        btnOverlay = findViewById(R.id.btn_overlay)
        btnAccess = findViewById(R.id.btn_access)
        btnBattery = findViewById(R.id.btn_battery)

        toggle.setOnClickListener {
            if (AstriaService.running) {
                startService(Intent(this, AstriaService::class.java).setAction(AstriaService.ACTION_STOP))
                main.postDelayed({ refresh() }, 500)
            } else if (!granted(Manifest.permission.RECORD_AUDIO)) {
                Toast.makeText(this, "Autorisez d'abord le micro (étape 1).", Toast.LENGTH_LONG).show()
            } else {
                ContextCompat.startForegroundService(this, Intent(this, AstriaService::class.java))
                main.postDelayed({ refresh() }, 600)
            }
        }
        talk.setOnClickListener {
            if (!granted(Manifest.permission.RECORD_AUDIO)) {
                Toast.makeText(this, "Autorisez d'abord le micro (étape 1).", Toast.LENGTH_LONG).show()
            } else {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, AstriaService::class.java).setAction(AstriaService.ACTION_TRIGGER)
                )
                main.postDelayed({ refresh() }, 600)
            }
        }
        btnPerms.setOnClickListener { ActivityCompat.requestPermissions(this, neededPermissions(), 11) }
        btnOverlay.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btnAccess.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btnBattery.setOnClickListener {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        findViewById<MaterialButton>(R.id.btn_settings).setOnClickListener { showSettings() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun refresh() {
        val permsOk = neededPermissions().all { granted(it) }
        val overlayOk = Settings.canDrawOverlays(this)
        val accessOk = AstriaAccessibility.instance != null
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val batteryOk = pm.isIgnoringBatteryOptimizations(packageName)

        btnPerms.text = "1 · Autoriser micro, contacts, SMS, agenda" + if (permsOk) "  ✓" else ""
        btnOverlay.text = "2 · Autoriser l'affichage par-dessus les applis" + if (overlayOk) "  ✓" else ""
        btnAccess.text = "3 · Activer le contrôle du téléphone" + if (accessOk) "  ✓" else ""
        btnBattery.text = "4 · Désactiver l'économie d'énergie" + if (batteryOk) "  ✓" else ""

        if (AstriaService.running) {
            status.text = "Astria est à l'écoute.\nDites « Astria »."
            toggle.text = "Désactiver Astria"
        } else {
            status.text = "Astria est en veille."
            toggle.text = "Activer Astria"
        }
    }

    private fun showSettings() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        fun label(t: String) = TextView(this).apply {
            text = t
            setPadding(0, pad / 2, 0, 0)
        }
        val city = EditText(this).apply {
            hint = "Ville pour la météo"
            setText(Prefs.city(this@MainActivity))
        }
        val country = EditText(this).apply {
            hint = "Indicatif du pays, par exemple 243"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Prefs.countryCode(this@MainActivity))
        }
        val key = EditText(this).apply {
            hint = "Clé Gemini gratuite"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Prefs.geminiKey(this@MainActivity))
        }
        val confirm = SwitchCompat(this).apply {
            text = "Demander ma confirmation avant chaque demande"
            isChecked = Prefs.confirmEvery(this@MainActivity)
        }
        val unlock = SwitchCompat(this).apply {
            text = "Messages, appels, contacts et agenda seulement si le téléphone est déverrouillé"
            isChecked = Prefs.requireUnlock(this@MainActivity)
        }
        val rate = SeekBar(this).apply {
            max = 10
            progress = (((Prefs.speechRate(this@MainActivity) - 0.6f) / 0.08f) + 0.5f).toInt().coerceIn(0, 10)
        }
        val pitch = SeekBar(this).apply {
            max = 10
            progress = (((Prefs.speechPitch(this@MainActivity) - 0.7f) / 0.06f) + 0.5f).toInt().coerceIn(0, 10)
        }
        box.addView(label("Ville"))
        box.addView(city)
        box.addView(label("Indicatif du pays (pour les numéros qui commencent par 0)"))
        box.addView(country)
        box.addView(label("Clé Gemini : le cerveau d'Astria (gratuite sur aistudio.google.com)"))
        box.addView(key)
        box.addView(label("Sécurité"))
        box.addView(confirm)
        box.addView(unlock)
        box.addView(label("Vitesse de la voix (de lente à rapide)"))
        box.addView(rate)
        box.addView(label("Hauteur de la voix (de grave à aiguë)"))
        box.addView(pitch)
        val scroll = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this)
            .setTitle("Réglages d'Astria")
            .setView(scroll)
            .setPositiveButton("Enregistrer") { _, _ ->
                val k = key.text.toString().trim()
                Prefs.save(
                    this, city.text.toString(), k, country.text.toString(), confirm.isChecked,
                    unlock.isChecked, 0.6f + rate.progress * 0.08f, 0.7f + pitch.progress * 0.06f
                )
                if (k.isNotEmpty()) testKey(k)
                Toast.makeText(this, "Réglages enregistrés. La voix change au prochain démarrage d'Astria.", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    /** Vérifie que la clé Gemini fonctionne et le dit à l'écran. */
    private fun testKey(k: String) {
        Thread {
            val msg = try {
                if (Brain.interpret("quelle heure est-il", k) != null) {
                    "Clé Gemini : ça marche."
                } else {
                    "Clé Gemini : réponse inattendue."
                }
            } catch (e: Exception) {
                "Clé Gemini refusée ou pas d'internet (" + (e.message ?: "erreur") + ")."
            }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }
}
