# Astria — assistante vocale personnelle (Android)

Astria répond **uniquement par la voix**, avec une voix féminine douce. Pour l'appeler, dites **« Astria »** : elle répond toujours **« Oui monsieur, que puis-je faire pour vous ? »**. Elle répète ce qu'elle va faire et attend votre « oui » avant chaque demande.

100 % gratuit : aucune API payante. Les actions du téléphone fonctionnent sans internet ; seuls la météo et les recherches web utilisent internet.

## Ce qu'Astria sait faire

| Domaine | Exemples de phrases | Internet |
|---|---|---|
| Heure, date, batterie | « Quelle heure est-il ? » · « Quel jour sommes-nous ? » · « Niveau de batterie » | non |
| Alarme, minuteur | « Mets une alarme à 6 heures 30 » · « Minuteur de 10 minutes » | non |
| Appels | « Appelle maman » | non |
| SMS | « Envoie un SMS à Marie que j'arrive » · « Lis mes messages » | non |
| Réseaux sociaux | « Envoie un message WhatsApp à Marie que je suis en retard » (aussi Telegram, Messenger, Instagram, Facebook, X, LinkedIn) | non |
| Contacts | « Quel est le numéro de maman ? » | non |
| Agenda | « Qu'est-ce que j'ai demain ? » · « Ajoute un rendez-vous avec le docteur demain à 10 heures » | non |
| Applications | « Ouvre WhatsApp » · « Lance l'application YouTube » | non |
| Écran d'accueil et navigation | « Va à l'écran d'accueil » · « Retour » · « Capture d'écran » · « Ouvre les notifications » · « Verrouille le téléphone » | non |
| Lampe, volume | « Allume la lampe torche » · « Monte le volume » | non |
| Réglages | « Ouvre les paramètres Wi-Fi » | non |
| Météo | « Quel temps fait-il à Lubumbashi ? » · « La météo de demain » | oui |
| Web | « Cherche la recette du pondu » · « Qui est le président de la France ? » · « Ouvre google point com » | oui |

Si une information manque (destinataire, heure…), Astria la demande à la voix.

## Version 1.1 : le cerveau Gemini (nouveau)

- **Où mettre la clé Gemini ?** Dans l'appli Astria : bouton **Réglages**, champ « Clé Gemini ». Jamais dans le code ni sur GitHub. Après « Enregistrer », Astria teste la clé et affiche « ça marche » ou l'erreur.
- **Ce que ça change** : quand les règles locales ne comprennent pas une phrase (« raconte-moi une blague », « je voudrais voir mes photos »), Gemini la traduit en une action qu'Astria connaît. Astria demande toujours votre confirmation avant d'agir. Gemini ne commande pas le téléphone lui-même. Sans clé, Astria fonctionne comme avant.
- **Recherche Google** : « Astria, fais une recherche sur Google » ouvre maintenant vraiment Google dans le navigateur (avant, elle répondait à voix haute avec Wikipédia).
- **Galerie, calculatrice, contacts, appareil photo, messages, musique, agenda, cartes, e-mails, navigateur** : Astria les ouvre par leur fonction, même si l'appli porte un autre nom sur votre téléphone.
- **Contacts** : recherche plus tolérante (mot du nom, petite erreur de reconnaissance vocale). Si l'autorisation de lire les contacts manque, Astria le dit au lieu de répondre « introuvable ».
- **Réglages** : ville, indicatif du pays, confirmation avant chaque demande, déverrouillage obligatoire, vitesse et hauteur de la voix.

## Compiler l'APK avec GitHub (comme avant)

1. Sur votre dépôt GitHub, supprimez l'ancien `Lux-android-projet.zip` puis envoyez le nouveau (**Add file → Upload files**). Le même nom de fichier est conservé volontairement : votre fichier de compilation actuel (`apk.yml`) fonctionne sans changement.
2. Validez. La compilation démarre seule (**Plus → Actions**, 3 à 5 minutes).
3. Quand elle est verte, ouvrez l'exécution « Lux APK v2 », téléchargez **Lux-APK** en bas de page, extrayez et installez `app-debug.apk`.
4. Astria s'installe comme une **nouvelle appli** (« Astria ») ; vous pouvez désinstaller l'ancienne « Lux ». Les prochaines versions s'installeront par-dessus sans perdre vos réglages.

Alternative : Android Studio sur ordinateur (File → Open → dossier `Lux`, puis Run).

## Première configuration (5 minutes)

Ouvrez **Astria** et suivez les 4 boutons dans l'ordre :

1. **Autoriser micro, contacts, SMS, agenda.**
   Sur Android 13 et plus, si les SMS sont grisés : Paramètres → Applications → Astria → menu ⋮ en haut à droite → **Autoriser les paramètres restreints**, puis revenez accorder les autorisations.
2. **Autoriser l'affichage par-dessus les applis.** Sans cela, Android peut empêcher Astria d'ouvrir une application quand elle travaille en arrière-plan.
3. **Activer le contrôle du téléphone** : Accessibilité → Astria → activer. Il permet de revenir à l'accueil, de faire retour, de capturer l'écran et de toucher le bouton « Envoyer » dans WhatsApp et les autres. Même menu ⋮ « paramètres restreints » si Android bloque l'activation.
4. **Désactiver l'économie d'énergie** pour Astria : sinon Android l'endort et elle n'entend plus « Astria ».

Puis touchez **Activer Astria** : une notification « Astria est à l'écoute » apparaît. Pour tester sans dire le mot d'éveil : **Parler à Astria maintenant**.

**Reconnaissance vocale hors ligne** (recommandé) : Paramètres → Applications par défaut / Google → Reconnaissance vocale hors connexion → téléchargez **Français**. Sans ce paquet, Android envoie votre voix aux serveurs de Google pour la transcrire.

**Voix féminine** : installez « Synthèse vocale Google », puis Paramètres → Synthèse vocale → Français : choisissez une voix féminine si Astria n'en prend pas une toute seule.

## Limites à connaître (honnêteté)

- **Reconnaissance de votre voix : non incluse.** Android ne propose pas d'identification du locuteur fiable sans modèle dédié. À la place : confirmation vocale de chaque demande, et messages, appels, contacts et agenda refusés si le téléphone est **verrouillé** (réglable dans `Config.kt`). N'importe qui peut en revanche dire « Astria » près d'un téléphone déverrouillé.
- **Écoute permanente = batterie.** Le mot d'éveil repose sur la reconnaissance vocale d'Android en boucle : consommation plus élevée, parfois un petit bip, et « Astria » peut être mal compris. Après un redémarrage du téléphone, rouvrez l'appli et touchez Activer.
- **Envoi des messages** : SMS et WhatsApp (avec contact enregistré) sont les plus fiables. Pour les autres réseaux, Astria ouvre le partage, cherche le contact par son nom et touche « Envoyer » ; si elle n'y arrive pas, elle vous le dit.
- **Wi-Fi, Bluetooth, mode avion** : Android interdit de les activer par programme ; Astria ouvre l'écran de réglage.
- **Web** : Wikipédia et DuckDuckGo (gratuits, sans clé). Pour de meilleures réponses, vous pouvez coller une clé **Gemini gratuite** (aistudio.google.com) dans Réglages : sans recherche en direct, donc moins à jour sur l'actualité.
- **Écrit sans pouvoir être testé sur un téléphone** : le moteur de compréhension des phrases est testé (103 tests réussis), mais la compilation et le comportement réel sont à vérifier. Envoyez-moi les erreurs ou ce qui ne marche pas, je corrige.

## Personnaliser (`app/src/main/java/com/astria/assistant/Config.kt`)

- `DEFAULT_CITY` : ville pour la météo (Kinshasa)
- `CONFIRM_EVERY_REQUEST` : `false` pour ne confirmer que les actions importantes
- `REQUIRE_UNLOCK_FOR_SENSITIVE` : `false` pour autoriser même téléphone verrouillé
- `SPEECH_RATE`, `SPEECH_PITCH` : débit et douceur de la voix
