package com.astria.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Contrôle du téléphone : revenir à l'accueil, retour, applications récentes, notifications,
 * capture d'écran, verrouillage, et toucher des boutons (par exemple « Envoyer »).
 * À activer une fois dans Réglages > Accessibilité > Astria.
 */
class AstriaAccessibility : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AstriaAccessibility? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun perform(action: String): Boolean = when (action) {
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        "notifs" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        "lock" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else false
        "screenshot" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) else false
        else -> false
    }

    /** Touche le premier élément visible dont le texte (ou la description) correspond. */
    fun clickText(vararg labels: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (label in labels) {
            if (label.isBlank()) continue
            val nodes = root.findAccessibilityNodeInfosByText(label) ?: continue
            for (node in nodes) {
                var cur: AccessibilityNodeInfo? = node
                var depth = 0
                while (cur != null && depth < 6) {
                    if (cur.isClickable && cur.isEnabled && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return true
                    }
                    cur = cur.parent
                    depth++
                }
            }
        }
        return false
    }
}
