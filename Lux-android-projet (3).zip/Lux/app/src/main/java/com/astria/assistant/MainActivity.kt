package com.astria.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

/**
 * Écran de configuration d'Astria. Astria ne répond QUE par la voix : cet écran sert seulement
 * à l'activer, à lui donner les autorisations et à régler la ville et la clé Gemini (facultative).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var toggle: MaterialButton
    private lateinit var talk: MaterialButton
    private lateinit var btnPerms: MaterialButton
    private lateinit var btnOverlay: MaterialButton
    private lateinit var btnAccess: MaterialButton
    private lateinit var btnBattery: MaterialButton
    private val main = Handler(Looper.getMainLooper())

    private fun neededPermissions(): Array<String> {
        val list = arrayListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        return list.toTypedArray()
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        toggle = findViewById(R.id.btn_toggle)
        talk = findViewById(R.id.btn_talk)
        btnPerms = findViewById(R.id.btn_perms)
        btnOverlay = findViewById(R.id.btn_overlay)
        btnAccess = findViewById(R.id.btn_access)
        btnBattery = findViewById(R.id.btn_battery)

        toggle.setOnClickListener {
            if (AstriaService.running) {
                startService(Intent(this, AstriaService::class.java).setAction(AstriaService.ACTION_STOP))
                main.postDelayed({ refresh() }, 500)
            } else if (!granted(Manifest.permission.RECORD_AUDIO)) {
                Toast.makeText(this, "Autorisez d'abord le micro (étape 1).", Toast.LENGTH_LONG).show()
            } else {
                ContextCompat.startForegroundService(this, Intent(this, AstriaService::class.java))
                main.postDelayed({ refresh() }, 600)
            }
        }
        talk.setOnClickListener {
            if (!granted(Manifest.permission.RECORD_AUDIO)) {
                Toast.makeText(this, "Autorisez d'abord le micro (étape 1).", Toast.LENGTH_LONG).show()
            } else {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, AstriaService::class.java).setAction(AstriaService.ACTION_TRIGGER)
                )
                main.postDelayed({ refresh() }, 600)
            }
        }
        btnPerms.setOnClickListener { ActivityCompat.requestPermissions(this, neededPermissions(), 11) }
        btnOverlay.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btnAccess.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btnBattery.setOnClickListener {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        findViewById<MaterialButton>(R.id.btn_settings).setOnClickListener { showSettings() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun refresh() {
        val permsOk = neededPermissions().all { granted(it) }
        val overlayOk = Settings.canDrawOverlays(this)
        val accessOk = AstriaAccessibility.instance != null
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val batteryOk = pm.isIgnoringBatteryOptimizations(packageName)

        btnPerms.text = "1 · Autoriser micro, contacts, SMS, agenda" + if (permsOk) "  ✓" else ""
        btnOverlay.text = "2 · Autoriser l'affichage par-dessus les applis" + if (overlayOk) "  ✓" else ""
        btnAccess.text = "3 · Activer le contrôle du téléphone" + if (accessOk) "  ✓" else ""
        btnBattery.text = "4 · Désactiver l'économie d'énergie" + if (batteryOk) "  ✓" else ""

        if (AstriaService.running) {
            status.text = "Astria est à l'écoute.\nDites « Astria »."
            toggle.text = "Désactiver Astria"
        } else {
            status.text = "Astria est en veille."
            toggle.text = "Activer Astria"
        }
    }

    private fun showSettings() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val city = EditText(this).apply {
            hint = "Ville pour la météo"
            setText(Prefs.city(this@MainActivity))
        }
        val key = EditText(this).apply {
            hint = "Clé Gemini gratuite (facultatif)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Prefs.geminiKey(this@MainActivity))
        }
        box.addView(city)
        box.addView(key)
        AlertDialog.Builder(this)
            .setTitle("Réglages d'Astria")
            .setMessage("La clé Gemini sert aux questions générales. Sans clé, Astria utilise Wikipédia.")
            .setView(box)
            .setPositiveButton("Enregistrer") { _, _ ->
                Prefs.save(this, city.text.toString(), key.text.toString())
            }
            .setNegativeButton("Annuler", null)
            .show()
    }
}
