package com.astria.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Tout ce qui demande internet : météo et recherche web.
 * Sources gratuites et sans clé : Open-Meteo, Wikipédia, DuckDuckGo.
 * Gemini (clé gratuite Google AI Studio) est un plus facultatif.
 * Ces fonctions bloquent : à appeler hors du fil principal.
 */
object Web {

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun request(url: String, body: String? = null, headers: Map<String, String> = emptyMap()): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 15000
        conn.setRequestProperty("User-Agent", "Astria/1.0 (Android assistant)")
        conn.setRequestProperty("Accept", "application/json")
        for ((k, v) in headers) conn.setRequestProperty(k, v)
        if (body != null) {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        return text
    }

    // ---------------------------------------------------------------- météo

    private fun weatherText(code: Int): String = when (code) {
        0 -> "ciel dégagé"
        1 -> "plutôt dégagé"
        2 -> "partiellement nuageux"
        3 -> "ciel couvert"
        45, 48 -> "brouillard"
        51, 53, 55, 56, 57 -> "bruine"
        61, 63, 65, 66, 67 -> "pluie"
        71, 73, 75, 77, 85, 86 -> "neige"
        80, 81, 82 -> "averses"
        95, 96, 99 -> "orage"
        else -> "temps variable"
    }

    fun weather(city: String, tomorrow: Boolean): String {
        val geo = JSONObject(
            request("https://geocoding-api.open-meteo.com/v1/search?name=${enc(city)}&count=1&language=fr")
        )
        val results: JSONArray = geo.optJSONArray("results")
            ?: return "Je ne trouve pas la ville $city, monsieur."
        val r = results.getJSONObject(0)
        val name = r.optString("name", city)
        val lat = r.getDouble("latitude")
        val lon = r.getDouble("longitude")

        val f = JSONObject(
            request(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                    "&timezone=auto&forecast_days=2"
            )
        )
        val daily = f.getJSONObject("daily")
        val i = if (tomorrow) 1 else 0
        val tmax = Math.round(daily.getJSONArray("temperature_2m_max").getDouble(i))
        val tmin = Math.round(daily.getJSONArray("temperature_2m_min").getDouble(i))
        val rain = daily.getJSONArray("precipitation_probability_max").optInt(i, 0)
        val dayCode = daily.getJSONArray("weather_code").getInt(i)

        val rainText = if (rain >= 30) " Risque de pluie : $rain pour cent." else " Peu de risque de pluie."
        return if (tomorrow) {
            "Demain à $name, ${weatherText(dayCode)}, minimale $tmin degrés, maximale $tmax degrés.$rainText"
        } else {
            val cur = f.getJSONObject("current")
            val temp = Math.round(cur.getDouble("temperature_2m"))
            val curText = weatherText(cur.getInt("weather_code"))
            "À $name, il fait $temp degrés, $curText. Aujourd'hui, minimale $tmin, maximale $tmax.$rainText"
        }
    }

    // ---------------------------------------------------------------- recherche web

    fun answer(query: String, geminiKey: String): String {
        if (geminiKey.isNotBlank()) {
            try {
                val g = gemini(query, geminiKey)
                if (g.isNotBlank()) return g
            } catch (e: Exception) {
                // on retombe sur les sources sans clé
            }
        }
        try {
            val w = wikipedia(query)
            if (w != null) return w
        } catch (e: Exception) {
        }
        try {
            val d = duckduckgo(query)
            if (d != null) return d
        } catch (e: Exception) {
        }
        return "Je n'ai trouvé aucune réponse fiable à cette question, monsieur."
    }

    private fun shorten(text: String, sentences: Int = 2, maxChars: Int = 420): String {
        val clean = text.replace(Regex("\\s+"), " ").replace(Regex("\\([^)]*\\)"), "").trim()
        val parts = clean.split(Regex("(?<=[.!?])\\s+"))
        var out = parts.take(sentences).joinToString(" ")
        if (out.length > maxChars) out = out.take(maxChars).substringBeforeLast(' ') + "…"
        return out
    }

    private fun gemini(query: String, key: String): String {
        val prompt = "Tu es Astria, une assistante vocale. Réponds en français, en deux phrases au maximum, " +
            "sans markdown, sans liste, pour être lue à voix haute. Question : $query"
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))
            )
            .put("generationConfig", JSONObject().put("maxOutputTokens", 220))
            .toString()
        val raw = request(
            "https://generativelanguage.googleapis.com/v1beta/models/${Config.GEMINI_MODEL}:generateContent",
            body,
            mapOf("x-goog-api-key" to key)
        )
        val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return shorten(sb.toString(), 3, 500)
    }

    private fun wikipedia(query: String): String? {
        val search = JSONObject(
            request("https://fr.wikipedia.org/w/api.php?action=query&list=search&srsearch=${enc(query)}&format=json&srlimit=1&utf8=1")
        )
        val hits = search.getJSONObject("query").getJSONArray("search")
        if (hits.length() == 0) return null
        val title = hits.getJSONObject(0).getString("title")
        val path = enc(title.replace(' ', '_')).replace("+", "%20")
        val summary = JSONObject(request("https://fr.wikipedia.org/api/rest_v1/page/summary/$path"))
        val extract = summary.optString("extract")
        if (extract.isBlank()) return null
        return shorten(extract)
    }

    private fun duckduckgo(query: String): String? {
        val j = JSONObject(request("https://api.duckduckgo.com/?q=${enc(query)}&format=json&no_html=1&skip_disambig=1"))
        val text = j.optString("Answer").ifBlank { j.optString("AbstractText") }
        return if (text.isBlank()) null else shorten(text)
    }
}
