package com.astria.assistant

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import com.astria.assistant.CommandParser.Command
import com.astria.assistant.CommandParser.Type
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Exécute les demandes d'Astria. Tout ce qui touche le téléphone fonctionne sans internet. */
class Actions(private val ctx: Context) {

    private val main = Handler(Looper.getMainLooper())

    companion object {
        private val SOCIAL = mapOf(
            "whatsapp" to "com.whatsapp",
            "telegram" to "org.telegram.messenger",
            "messenger" to "com.facebook.orca",
            "instagram" to "com.instagram.android",
            "facebook" to "com.facebook.katana",
            "x" to "com.twitter.android",
            "linkedin" to "com.linkedin.android"
        )
        private val SENSITIVE = setOf(
            Type.CALL, Type.SMS, Type.SOCIAL, Type.READ_SMS, Type.CONTACT_INFO, Type.CAL_READ, Type.CAL_ADD
        )
    }

    fun isSensitive(c: Command): Boolean = c.type in SENSITIVE

    // ------------------------------------------------------------------ phrase de confirmation

    fun describe(c: Command): String = when (c.type) {
        Type.TIME -> "vous donner l'heure"
        Type.DATE -> "vous donner la date"
        Type.BATTERY -> "vous donner le niveau de la batterie"
        Type.WEATHER -> {
            val city = c.get("city").ifBlank { Prefs.city(ctx) }
            "vous donner la météo " + (if (c.get("tomorrow") == "1") "de demain " else "") + "à $city"
        }
        Type.ALARM -> "programmer une alarme à ${c.geti("hour", 0)} heures ${"%02d".format(c.geti("minute", 0))}"
        Type.TIMER -> "lancer un minuteur de ${spokenDuration(c.geti("seconds", 0))}"
        Type.CALL -> "appeler ${c.get("recipient")}"
        Type.SMS -> "envoyer ce SMS à ${c.get("recipient")} : « ${c.get("message")} »"
        Type.SOCIAL -> "envoyer sur ${c.get("app")} à ${c.get("recipient")} : « ${c.get("message")} »"
        Type.READ_SMS -> "lire vos derniers messages"
        Type.CONTACT_INFO -> "chercher le numéro de ${c.get("name").ifBlank { c.get("recipient") }}"
        Type.CAL_READ -> "lire votre agenda " + dayWord(c.geti("offset", 0))
        Type.CAL_ADD -> "ajouter à votre agenda « ${c.get("title")} » ${spokenDate(c.get("date"))} à " +
            "${c.geti("hour", 0)} heures ${"%02d".format(c.geti("minute", 0))}"
        Type.OPEN_APP -> "ouvrir l'application ${c.get("name")}"
        Type.OPEN_URL -> "ouvrir la page web demandée"
        Type.WEB_ASK -> "chercher sur internet : ${c.get("query")}"
        Type.FLASHLIGHT -> if (c.get("state") == "off") "éteindre la lampe torche" else "allumer la lampe torche"
        Type.VOLUME -> "régler le volume"
        Type.NAV -> when (c.get("action")) {
            "home" -> "revenir à l'écran d'accueil"
            "back" -> "revenir en arrière"
            "recents" -> "afficher les applications récentes"
            "notifs" -> "ouvrir les notifications"
            "lock" -> "verrouiller le téléphone"
            "screenshot" -> "faire une capture d'écran"
            else -> "naviguer dans le téléphone"
        }
        Type.SETTINGS -> "ouvrir les réglages"
        else -> "exécuter cette demande"
    }

    private fun dayWord(offset: Int) = when (offset) {
        0 -> "d'aujourd'hui"
        1 -> "de demain"
        else -> "d'après-demain"
    }

    private fun spokenDate(iso: String): String {
        return try {
            val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(iso) ?: return ""
            "le " + SimpleDateFormat("EEEE d MMMM", Locale.FRENCH).format(d)
        } catch (e: Exception) {
            ""
        }
    }

    private fun spokenDuration(totalSeconds: Int): String {
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add("$h heure" + if (h > 1) "s" else "")
        if (m > 0) parts.add("$m minute" + if (m > 1) "s" else "")
        if (s > 0 || parts.isEmpty()) parts.add("$s seconde" + if (s > 1) "s" else "")
        return parts.joinToString(" ")
    }

    // ------------------------------------------------------------------ exécution

    /** [done] est toujours appelé une seule fois, sur le fil principal, avec la phrase à dire. */
    fun execute(c: Command, done: (String) -> Unit) {
        try {
            when (c.type) {
                Type.WEATHER -> {
                    val city = c.get("city").ifBlank { Prefs.city(ctx) }
                    val tomorrow = c.get("tomorrow") == "1"
                    background({ Web.weather(city, tomorrow) }, done)
                }
                Type.WEB_ASK -> {
                    val q = c.get("query")
                    val key = Prefs.geminiKey(ctx)
                    background({ Web.answer(q, key) }, done)
                }
                Type.SOCIAL -> social(c, done)
                else -> done(runSync(c))
            }
        } catch (e: SecurityException) {
            done("Une autorisation manque sur le téléphone, monsieur. Ouvrez l'application Astria pour l'accorder.")
        } catch (e: ActivityNotFoundException) {
            done("Aucune application ne peut faire cela, monsieur.")
        } catch (e: Exception) {
            done("Je n'ai pas pu terminer cette action, monsieur.")
        }
    }

    private fun background(block: () -> String, done: (String) -> Unit) {
        Thread {
            val r = try {
                block()
            } catch (e: Exception) {
                "Je n'arrive pas à joindre internet, monsieur."
            }
            main.post { done(r) }
        }.start()
    }

    private fun runSync(c: Command): String = when (c.type) {
        Type.TIME -> time()
        Type.DATE -> "Nous sommes le " + SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH).format(Date()) + ", monsieur."
        Type.BATTERY -> battery()
        Type.ALARM -> alarm(c)
        Type.TIMER -> timer(c)
        Type.CALL -> call(c)
        Type.SMS -> sms(c)
        Type.READ_SMS -> readSms()
        Type.CONTACT_INFO -> contactInfo(c)
        Type.CAL_READ -> calRead(c)
        Type.CAL_ADD -> calAdd(c)
        Type.OPEN_APP -> openApp(c)
        Type.OPEN_URL -> openUrl(c)
        Type.SETTINGS -> settings(c)
        Type.FLASHLIGHT -> flashlight(c)
        Type.VOLUME -> volume(c)
        Type.NAV -> nav(c)
        else -> "Je ne sais pas encore faire cela, monsieur."
    }

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    // ------------------------------------------------------------------ heure, date, batterie

    private fun time(): String {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val m = cal.get(Calendar.MINUTE)
        val heures = if (h > 1) "heures" else "heure"
        return if (m == 0) "Il est $h $heures pile, monsieur." else "Il est $h $heures $m, monsieur."
    }

    private fun battery(): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val st = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val plugged = (st?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        return "La batterie est à $pct pour cent" + (if (plugged) ", en charge" else "") + ", monsieur."
    }

    // ------------------------------------------------------------------ alarme, minuteur

    private fun alarm(c: Command): String {
        val h = c.geti("hour", 0)
        val m = c.geti("minute", 0)
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Astria")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        launch(i)
        return "L'alarme est programmée à $h heures ${"%02d".format(m)}, monsieur."
    }

    private fun timer(c: Command): String {
        val s = c.geti("seconds", 0)
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, s)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Astria")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        launch(i)
        return "Le minuteur de ${spokenDuration(s)} est lancé, monsieur."
    }

    // ------------------------------------------------------------------ contacts, appels, SMS

    private fun plain(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase(Locale.ROOT).trim()

    /** @return (nom affiché, numéro) ou null. */
    private fun findNumber(who: String): Pair<String, String>? {
        val trimmed = who.trim()
        if (trimmed.isEmpty()) return null
        if (trimmed.none { it.isLetter() } && trimmed.count { it.isDigit() } >= 6) {
            return Pair(trimmed, trimmed.filter { it.isDigit() || it == '+' })
        }
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val target = plain(trimmed)
        var best: Pair<String, String>? = null
        var bestScore = 0
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )
        cursor?.use {
            while (it.moveToNext()) {
                val name = it.getString(0) ?: continue
                val number = it.getString(1) ?: continue
                val p = plain(name)
                val score = when {
                    p == target -> 3
                    p.startsWith(target) -> 2
                    p.contains(target) -> 1
                    else -> 0
                }
                if (score > bestScore) {
                    bestScore = score
                    best = Pair(name, number)
                }
            }
        }
        return best
    }

    private fun digitsToSpeech(n: String): String =
        n.filter { it.isDigit() || it == '+' }.map { if (it == '+') "plus" else it.toString() }.joinToString(" ")

    private fun international(number: String): String {
        val d = number.filter { it.isDigit() || it == '+' }
        val out = when {
            d.startsWith("+") -> d.drop(1)
            d.startsWith("00") -> d.drop(2)
            d.startsWith("0") -> Config.DEFAULT_COUNTRY_CODE + d.drop(1)
            else -> d
        }
        return out.filter { it.isDigit() }
    }

    private fun call(c: Command): String {
        val who = c.get("recipient")
        val found = findNumber(who) ?: return "Je ne trouve pas $who dans vos contacts, monsieur."
        val uri = Uri.fromParts("tel", found.second, null)
        if (has(Manifest.permission.CALL_PHONE)) {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.placeCall(uri, Bundle())
            return "J'appelle ${found.first}, monsieur."
        }
        launch(Intent(Intent.ACTION_DIAL, uri))
        return "Le numéro de ${found.first} est composé, monsieur. Touchez le bouton d'appel."
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun sms(c: Command): String {
        val who = c.get("recipient")
        val msg = c.get("message")
        val found = findNumber(who) ?: return "Je ne trouve pas $who dans vos contacts, monsieur."
        if (!has(Manifest.permission.SEND_SMS)) {
            launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(found.second))).putExtra("sms_body", msg))
            return "Le SMS est prêt, monsieur, mais l'autorisation d'envoyer des SMS manque. Touchez Envoyer."
        }
        val sm = smsManager()
        sm.sendMultipartTextMessage(found.second, null, sm.divideMessage(msg), null, null)
        return "Le SMS est envoyé à ${found.first}, monsieur."
    }

    private fun readSms(): String {
        if (!has(Manifest.permission.READ_SMS)) {
            return "Je n'ai pas l'autorisation de lire vos messages, monsieur."
        }
        val cursor = ctx.contentResolver.query(
            Uri.parse("content://sms/inbox"),
            arrayOf("address", "body"),
            null, null, "date DESC LIMIT 3"
        ) ?: return "Je n'arrive pas à lire vos messages, monsieur."
        val lines = ArrayList<String>()
        cursor.use {
            while (it.moveToNext()) {
                val address = it.getString(0) ?: ""
                val body = (it.getString(1) ?: "").replace(Regex("\\s+"), " ").take(220)
                lines.add("De ${contactName(address)} : $body")
            }
        }
        if (lines.isEmpty()) return "Vous n'avez aucun message, monsieur."
        return "Voici vos derniers messages, monsieur. " + lines.joinToString(". ")
    }

    private fun contactName(address: String): String {
        if (address.isBlank() || !has(Manifest.permission.READ_CONTACTS)) return address
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address))
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else address } ?: address
        } catch (e: Exception) {
            address
        }
    }

    private fun contactInfo(c: Command): String {
        val who = c.get("name").ifBlank { c.get("recipient") }
        val found = findNumber(who) ?: return "Je ne trouve pas $who dans vos contacts, monsieur."
        return "Le numéro de ${found.first} est le ${digitsToSpeech(found.second)}."
    }

    // ------------------------------------------------------------------ réseaux sociaux

    private fun social(c: Command, done: (String) -> Unit) {
        val app = c.get("app")
        val msg = c.get("message")
        val who = c.get("recipient")
        val pkg = SOCIAL[app]
        if (pkg == null) {
            done("Je ne sais pas encore utiliser $app, monsieur.")
            return
        }
        var direct = false
        if (app == "whatsapp") {
            val found = findNumber(who)
            if (found != null) {
                val uri = Uri.parse("https://wa.me/${international(found.second)}?text=${Uri.encode(msg)}")
                try {
                    launch(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg))
                } catch (e: ActivityNotFoundException) {
                    launch(Intent(Intent.ACTION_VIEW, uri))
                }
                direct = true
            }
        }
        if (!direct) {
            launch(
                Intent(Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, msg)
                    .setPackage(pkg)
            )
        }
        if (AstriaAccessibility.instance == null) {
            done("Le message est prêt dans $app, monsieur. Activez le contrôle du téléphone pour que je touche Envoyer moi-même.")
            return
        }
        main.postDelayed({ autoSend(app, who, !direct, 0, false, done) }, 2500)
    }

    /** Touche « Envoyer » grâce au service d'accessibilité (avec quelques essais). */
    private fun autoSend(app: String, who: String, pick: Boolean, step: Int, picked: Boolean, done: (String) -> Unit) {
        val svc = AstriaAccessibility.instance
        if (svc == null || step > 8) {
            done("Le message est préparé dans $app, monsieur, mais je n'ai pas pu toucher Envoyer. Touchez-le vous-même.")
            return
        }
        if (pick && !picked) {
            if (svc.clickText(who)) {
                main.postDelayed({ autoSend(app, who, pick, step + 1, true, done) }, 1500)
            } else {
                main.postDelayed({ autoSend(app, who, pick, step + 1, false, done) }, 1200)
            }
        } else {
            if (svc.clickText("Envoyer", "Send", "ENVOYER", "SEND")) {
                done("C'est envoyé, monsieur.")
            } else {
                main.postDelayed({ autoSend(app, who, pick, step + 1, picked, done) }, 1200)
            }
        }
    }

    // ------------------------------------------------------------------ agenda

    private fun calRead(c: Command): String {
        if (!has(Manifest.permission.READ_CALENDAR)) return "Je n'ai pas l'autorisation de lire votre agenda, monsieur."
        val offset = c.geti("offset", 0)
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.DAY_OF_MONTH, offset)
        }
        val begin = start.timeInMillis
        val end = begin + 24L * 3600 * 1000
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, begin)
        ContentUris.appendId(b, end)
        val cursor = ctx.contentResolver.query(
            b.build(),
            arrayOf(
                CalendarContract.Instances.TITLE,
                CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.ALL_DAY
            ),
            null, null, CalendarContract.Instances.BEGIN + " ASC"
        ) ?: return "Je n'arrive pas à lire votre agenda, monsieur."
        val items = ArrayList<String>()
        cursor.use {
            while (it.moveToNext()) {
                val title = it.getString(0) ?: "sans titre"
                val whenMs = it.getLong(1)
                val allDay = it.getInt(2) == 1
                if (allDay) {
                    items.add("toute la journée, $title")
                } else {
                    val cal = Calendar.getInstance().apply { timeInMillis = whenMs }
                    val h = cal.get(Calendar.HOUR_OF_DAY)
                    val m = cal.get(Calendar.MINUTE)
                    items.add("à $h heures" + (if (m > 0) " $m" else "") + ", $title")
                }
            }
        }
        val day = when (offset) {
            0 -> "aujourd'hui"
            1 -> "demain"
            else -> "après-demain"
        }
        if (items.isEmpty()) return "Vous n'avez rien de prévu $day, monsieur."
        return "Pour $day, monsieur : " + items.take(6).joinToString(". ")
    }

    private fun calAdd(c: Command): String {
        if (!has(Manifest.permission.WRITE_CALENDAR)) return "Je n'ai pas l'autorisation d'écrire dans votre agenda, monsieur."
        val parts = c.get("date").split("-")
        val cal = Calendar.getInstance()
        if (parts.size == 3) {
            cal.set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt())
        }
        cal.set(Calendar.HOUR_OF_DAY, c.geti("hour", 9))
        cal.set(Calendar.MINUTE, c.geti("minute", 0))
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val startMs = cal.timeInMillis

        var calId = -1L
        val cur = ctx.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            arrayOf(CalendarContract.Calendars._ID),
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL + " >= 500 AND " + CalendarContract.Calendars.VISIBLE + " = 1",
            null,
            CalendarContract.Calendars.IS_PRIMARY + " DESC"
        )
        cur?.use { if (it.moveToFirst()) calId = it.getLong(0) }
        if (calId < 0) return "Je ne trouve aucun agenda modifiable, monsieur."

        val values = ContentValues().apply {
            put(CalendarContract.Events.CALENDAR_ID, calId)
            put(CalendarContract.Events.TITLE, c.get("title"))
            put(CalendarContract.Events.DTSTART, startMs)
            put(CalendarContract.Events.DTEND, startMs + 3600_000L)
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
        }
        ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
        return "C'est ajouté à votre agenda, monsieur : ${c.get("title")}."
    }

    // ------------------------------------------------------------------ applications, web, réglages

    private fun openApp(c: Command): String {
        val name = plain(c.get("name"))
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val hit = apps.firstOrNull { plain(it.loadLabel(pm).toString()) == name }
            ?: apps.firstOrNull { plain(it.loadLabel(pm).toString()).contains(name) }
            ?: return "Je ne trouve pas l'application ${c.get("name")}, monsieur."
        val intent = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "Je n'arrive pas à ouvrir ${c.get("name")}, monsieur."
        launch(intent)
        return "J'ouvre ${hit.loadLabel(pm)}, monsieur."
    }

    private fun openUrl(c: Command): String {
        val url = c.get("url")
        if (!url.startsWith("https://") && !url.startsWith("http://")) return "Cette adresse n'est pas autorisée, monsieur."
        launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return "J'ouvre la page, monsieur."
    }

    private fun settings(c: Command): String {
        val (action, label) = when (c.get("target")) {
            "wifi" -> Pair(Settings.ACTION_WIFI_SETTINGS, "du Wi-Fi")
            "bluetooth" -> Pair(Settings.ACTION_BLUETOOTH_SETTINGS, "du Bluetooth")
            "data" -> Pair(Settings.ACTION_WIRELESS_SETTINGS, "des réseaux")
            "airplane" -> Pair(Settings.ACTION_AIRPLANE_MODE_SETTINGS, "du mode avion")
            "display" -> Pair(Settings.ACTION_DISPLAY_SETTINGS, "de l'affichage")
            else -> Pair(Settings.ACTION_SETTINGS, "du téléphone")
        }
        launch(Intent(action))
        return "J'ouvre les réglages $label, monsieur. Android ne me permet pas de les modifier moi-même."
    }

    // ------------------------------------------------------------------ lampe, volume, navigation

    private fun flashlight(c: Command): String {
        val on = c.get("state") != "off"
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Je ne trouve pas de lampe torche sur ce téléphone, monsieur."
        cm.setTorchMode(id, on)
        return if (on) "La lampe torche est allumée, monsieur." else "La lampe torche est éteinte, monsieur."
    }

    private fun volume(c: Command): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when (c.get("dir")) {
            "up" -> {
                repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0) }
                "J'ai monté le volume, monsieur."
            }
            "down" -> {
                repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0) }
                "J'ai baissé le volume, monsieur."
            }
            "max" -> {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0)
                "Le volume est au maximum, monsieur."
            }
            else -> {
                am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                "La sonnerie est coupée, le téléphone est en mode vibreur, monsieur."
            }
        }
    }

    private fun nav(c: Command): String {
        val svc = AstriaAccessibility.instance
            ?: return "Activez d'abord le contrôle du téléphone dans l'application Astria, monsieur."
        return if (svc.perform(c.get("action"))) "C'est fait, monsieur." else "Je n'ai pas pu le faire, monsieur."
    }
}
