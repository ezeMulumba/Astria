package com.astria.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/** Voix d'Astria : elle parle (synthèse vocale) et elle écoute (reconnaissance vocale). */
class Voice(private val ctx: Context, private val onReady: (Boolean) -> Unit) {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private val pendingDone = HashMap<String, () -> Unit>()

    val ready: Boolean get() = ttsReady

    init {
        tts = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) configureVoice()
            main.post { onReady(ttsReady) }
        }
    }

    private fun configureVoice() {
        val t = tts ?: return
        t.language = Locale.FRANCE
        t.setSpeechRate(Config.SPEECH_RATE)
        t.setPitch(Config.SPEECH_PITCH)
        val frVoices = t.voices?.filter { it.locale.language == "fr" } ?: emptyList()
        val pick = frVoices.firstOrNull { v ->
            Config.FEMALE_VOICE_HINTS.any { v.name.contains(it, ignoreCase = true) } &&
                v.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) != true
        }
        if (pick != null) t.voice = pick
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                finish(utteranceId)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                finish(utteranceId)
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                finish(utteranceId)
            }
        })
    }

    private fun finish(id: String?) {
        if (id == null) return
        val cb = synchronized(pendingDone) { pendingDone.remove(id) }
        if (cb != null) main.post { cb() }
    }

    /** Astria parle, puis appelle [onDone]. */
    fun speak(text: String, onDone: () -> Unit = {}) {
        val clean = text.replace(Regex("[*#_`>]"), "").replace(Regex("\\s+"), " ").trim()
        val t = tts
        if (!ttsReady || t == null || clean.isEmpty()) {
            main.post { onDone() }
            return
        }
        val limit = TextToSpeech.getMaxSpeechInputLength() - 1
        val id = UUID.randomUUID().toString()
        synchronized(pendingDone) { pendingDone[id] = onDone }
        t.speak(clean.take(limit), TextToSpeech.QUEUE_FLUSH, null, id)
    }

    /** Astria écoute une phrase. Un seul des deux rappels est appelé. */
    fun listen(preferOffline: Boolean, onResult: (String) -> Unit, onFail: (Int) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            main.post { onFail(SpeechRecognizer.ERROR_CLIENT) }
            return
        }
        stopListening()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}

            override fun onError(error: Int) {
                main.post {
                    if (recognizer === r) {
                        stopListening()
                        onFail(error)
                    }
                }
            }

            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                main.post {
                    if (recognizer === r) {
                        stopListening()
                        if (text.isNullOrBlank()) onFail(SpeechRecognizer.ERROR_NO_MATCH) else onResult(text)
                    }
                }
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        r.startListening(intent)
    }

    fun stopListening() {
        val r = recognizer
        recognizer = null
        try {
            r?.destroy()
        } catch (e: Exception) {
        }
    }

    /** Coupe la parole et l'écoute en cours. */
    fun stopAll() {
        synchronized(pendingDone) { pendingDone.clear() }
        tts?.stop()
        stopListening()
    }

    fun shutdown() {
        stopAll()
        tts?.shutdown()
        tts = null
    }
}
