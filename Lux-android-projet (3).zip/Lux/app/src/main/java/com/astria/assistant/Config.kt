package com.astria.assistant

import android.content.Context

/** Réglages principaux d'Astria. */
object Config {
    /** Première phrase d'Astria quand elle vous entend. */
    const val GREETING = "Oui monsieur, que puis-je faire pour vous ?"

    /** Ville utilisée pour la météo si vous n'en citez pas. */
    const val DEFAULT_CITY = "Kinshasa"

    /** Indicatif pour les numéros qui commencent par 0 (243 = RDC). */
    const val DEFAULT_COUNTRY_CODE = "243"

    /** true = Astria attend votre « oui » avant CHAQUE demande, même une simple heure. */
    const val CONFIRM_EVERY_REQUEST = true

    /** true = messages, appels, agenda et contacts seulement si le téléphone est déverrouillé. */
    const val REQUIRE_UNLOCK_FOR_SENSITIVE = true

    /** Modèle Gemini (gratuit avec une clé Google AI Studio, facultatif). */
    const val GEMINI_MODEL = "gemini-flash-latest"

    /** Voix douce : débit et hauteur (1.0 = neutre). */
    const val SPEECH_RATE = 0.93f
    const val SPEECH_PITCH = 1.1f

    /** Fragments de nom de voix Google féminines en français. */
    val FEMALE_VOICE_HINTS = listOf("-fra-", "-frc-", "female", "femme")
}

/** Réglages modifiables dans l'appli. */
object Prefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("astria", Context.MODE_PRIVATE)

    fun city(ctx: Context): String =
        p(ctx).getString("city", Config.DEFAULT_CITY)?.ifBlank { Config.DEFAULT_CITY } ?: Config.DEFAULT_CITY

    fun geminiKey(ctx: Context): String = p(ctx).getString("gemini", "")?.trim() ?: ""

    fun save(ctx: Context, city: String, geminiKey: String) {
        p(ctx).edit().putString("city", city.trim()).putString("gemini", geminiKey.trim()).apply()
    }
}
