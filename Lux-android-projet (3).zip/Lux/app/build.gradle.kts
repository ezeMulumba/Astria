plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.astria.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.astria.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Clé de signature fixe : les futures versions d'Astria s'installent par-dessus
    // sans perdre vos réglages. Usage personnel uniquement.
    signingConfigs {
        create("astria") {
            storeFile = file("astria.keystore")
            storePassword = "astria-perso-2026"
            keyAlias = "astria"
            keyPassword = "astria-perso-2026"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("astria")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("astria")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
