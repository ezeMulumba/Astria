package com.astria.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var listenButton: Button
    private var waitingForConfirmation = false
    private var pendingAction: (() -> Unit)? = null
    private val french = Locale.FRENCH

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 40)
        } else {
            prepareRecognizer()
        }
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
            setBackgroundColor(0xFF0B1020.toInt())
        }
        val title = TextView(this).apply {
            text = "ASTRIA"
            textSize = 34f
            setTextColor(0xFF77D7FF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Votre assistante personnelle"
            textSize = 16f
            setTextColor(0xFFEAF4FF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Touchez le bouton et dites : ASTRIA"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 48, 0, 48)
        }
        listenButton = Button(this).apply {
            text = "ACTIVER ASTRIA"
            textSize = 16f
            setOnClickListener { startListening() }
        }
        val note = TextView(this).apply {
            text = "Prototype vocal • Les actions sensibles demandent votre confirmation."
            textSize = 12f
            setTextColor(0xFFB7C6D9.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 36, 0, 0)
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(status)
        layout.addView(listenButton)
        layout.addView(note)
        setContentView(layout)
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts?.language = french
            // Prefer a French voice whose metadata/name suggests a feminine voice, if available.
            val candidate = tts?.voices?.firstOrNull {
                it.locale.language == "fr" && it.name.contains("female", ignoreCase = true)
            }
            if (candidate != null) tts?.voice = candidate
            speak("Oui monsieur, que puis-je faire pour vous ?")
        }
    }

    private fun speak(message: String) {
        status.text = message
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "astria-${System.currentTimeMillis()}")
    }

    private fun prepareRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Le service de reconnaissance vocale n'est pas disponible sur ce téléphone.")
            return
        }
        recognizer?.destroy()
        recognizer = if (android.os.Build.VERSION.SDK_INT >= 31 &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        } else {
            SpeechRecognizer.createSpeechRecognizer(this)
        }
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Je vous écoute…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Analyse de votre demande…" }
            override fun onError(error: Int) {
                status.text = "Écoute interrompue. Touchez pour réessayer."
            }
            override fun onResults(results: Bundle?) {
                val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                handlePhrase(phrase)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 40)
            return
        }
        if (recognizer == null) prepareRecognizer()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        listenButton.isEnabled = false
        recognizer?.startListening(intent)
        listenButton.postDelayed({ listenButton.isEnabled = true }, 4500)
    }

    private fun handlePhrase(raw: String) {
        val phrase = raw.lowercase(french).trim()
        if (phrase.isBlank()) {
            speak("Je n'ai pas compris. Pouvez-vous répéter ?")
            return
        }
        if (waitingForConfirmation) {
            if (listOf("oui", "confirme", "confirmer", "vas-y", "d'accord").any { phrase.contains(it) }) {
                waitingForConfirmation = false
                val action = pendingAction
                pendingAction = null
                speak("Très bien monsieur.")
                action?.invoke()
            } else {
                waitingForConfirmation = false
                pendingAction = null
                speak("Action annulée, monsieur.")
            }
            return
        }

        // Activation phrase is required before accepting a command in this prototype.
        if (!phrase.contains("astria")) {
            speak("Pour m'activer, dites ASTRIA, puis votre demande.")
            return
        }
        val command = phrase.substringAfter("astria").trim()
        if (command.isBlank()) {
            speak("Oui monsieur, que puis-je faire pour vous ?")
            return
        }
        routeCommand(command)
    }

    private fun confirm(message: String, action: () -> Unit) {
        waitingForConfirmation = true
        pendingAction = action
        speak("$message. Dites oui pour confirmer ou non pour annuler.")
    }

    private fun routeCommand(command: String) {
        when {
            command.contains("heure") -> {
                val now = SimpleDateFormat("HH:mm", french).format(Date())
                speak("Il est $now, monsieur.")
            }
            command.contains("date") -> {
                val today = SimpleDateFormat("EEEE d MMMM yyyy", french).format(Date())
                speak("Nous sommes le $today, monsieur.")
            }
            command.contains("ouvre") || command.contains("lance") -> {
                val app = command.substringAfter("ouvre", command.substringAfter("lance")).trim()
                openKnownApp(app)
            }
            command.contains("appelle") || command.contains("téléphone") -> {
                val person = command.substringAfter("appelle", command.substringAfter("téléphone")).trim()
                confirm("Voulez-vous ouvrir le téléphone pour appeler $person") {
                    val i = Intent(Intent.ACTION_DIAL).apply { data = Uri.parse("tel:") }
                    startActivity(i)
                }
            }
            command.contains("message") || command.contains("sms") -> {
                confirm("Voulez-vous ouvrir votre messagerie pour rédiger un SMS") {
                    startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))
                }
            }
            command.contains("recherche") || command.contains("cherche sur internet") -> {
                val query = command.substringAfter("recherche", command.substringAfter("cherche sur internet")).trim()
                confirm("Voulez-vous rechercher $query sur Internet") {
                    val url = "https://www.google.com/search?q=" + Uri.encode(query)
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
            }
            command.contains("paramètres") || command.contains("réglages") -> {
                confirm("Voulez-vous ouvrir les paramètres du téléphone") {
                    startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                }
            }
            else -> speak("Je peux déjà donner l'heure, la date, ouvrir certaines applications, préparer un appel, un message ou une recherche web. Cette fonction sera enrichie.")
        }
    }

    private fun openKnownApp(request: String) {
        val apps = mapOf(
            "whatsapp" to "com.whatsapp",
            "youtube" to "com.google.android.youtube",
            "facebook" to "com.facebook.katana",
            "instagram" to "com.instagram.android",
            "chrome" to "com.android.chrome",
            "appareil photo" to "com.android.camera2",
            "paramètres" to "com.android.settings"
        )
        val match = apps.entries.firstOrNull { request.contains(it.key) }
        if (match == null) {
            speak("Je ne reconnais pas encore cette application.")
            return
        }
        confirm("Voulez-vous ouvrir ${match.key}") {
            val launch = packageManager.getLaunchIntentForPackage(match.value)
            if (launch != null) startActivity(launch) else speak("Cette application n'est pas installée.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 40 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            prepareRecognizer()
            speak("Microphone autorisé. Touchez le bouton pour m'activer.")
        } else if (requestCode == 40) {
            speak("J'ai besoin de l'autorisation du microphone pour vous écouter.")
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
