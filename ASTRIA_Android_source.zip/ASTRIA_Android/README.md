# ASTRIA — prototype Android 0.1

ASTRIA est un premier socle Android natif en Kotlin. Il démontre une interface vocale, la synthèse vocale française, la reconnaissance vocale Android et quelques commandes locales / intents Android avec confirmation.

## Fonctions incluses
- Réponse vocale française via le moteur Text-to-Speech du téléphone.
- Écoute déclenchée par le bouton, puis reconnaissance de la phrase « ASTRIA ... ».
- Heure et date locales hors connexion.
- Ouverture de quelques applications (WhatsApp, YouTube, Facebook, Instagram, Chrome, paramètres), après confirmation.
- Préparation d'un appel, ouverture de la messagerie, recherche Web, avec confirmation.
- Reconnaissance sur appareil si Android et un moteur vocal compatible le permettent ; sinon le service vocal du téléphone peut nécessiter Internet.

## Limites honnêtes de cette version
- Ce n'est **pas encore** une écoute permanente « mot-clé ASTRIA » écran éteint. Android limite fortement l'accès au microphone en arrière-plan. Cette version utilise un bouton pour démarrer l'écoute.
- La reconnaissance de la voix du propriétaire n'est pas encore une authentification biométrique. Le système Android SpeechRecognizer transcrit la parole mais ne prouve pas l'identité du locuteur.
- Les appels, SMS et recherches ouvrent les applications système : ASTRIA ne les envoie pas seule. La confirmation dans l'app précède l'ouverture, et l'utilisateur garde la validation finale dans l'application cible.
- La sélection d'une voix féminine dépend des voix installées sur le téléphone. Si aucune voix féminine française n'est fournie, Android utilise sa voix française par défaut.
- Les contacts, lecture des messages privés, réseaux sociaux, contrôle complet de l'écran et météo ne sont pas inclus dans ce premier prototype.
- Il n'y a pas encore de cerveau conversationnel en ligne. Aucune clé API payante n'est requise pour compiler ou utiliser les fonctions locales présentes.

## Compiler gratuitement avec GitHub
1. Créer un dépôt GitHub et y envoyer le contenu de ce dossier.
2. Ouvrir l'onglet **Actions**.
3. Choisir **Build ASTRIA APK**, puis **Run workflow** (ou pousser un commit sur `main`).
4. À la fin du workflow, ouvrir l'exécution et télécharger l'artifact `ASTRIA-debug-apk`.
5. Extraire l'APK et l'installer sur le téléphone. Android peut demander d'autoriser l'installation depuis cette source.

## Compiler avec Android Studio
- Android Studio récent, JDK 17, Android SDK Platform 35.
- Ouvrir le dossier du projet, laisser Gradle synchroniser, puis lancer `:app:assembleDebug`.
- APK : `app/build/outputs/apk/debug/app-debug.apk`.

## Exemples de commandes
Après avoir touché **ACTIVER ASTRIA**, prononcer :
- « ASTRIA quelle heure est-il »
- « ASTRIA quelle est la date »
- « ASTRIA ouvre WhatsApp »
- « ASTRIA ouvre YouTube »
- « ASTRIA recherche les actualités de Kinshasa »
- « ASTRIA ouvre les paramètres »

Le projet est volontairement un prototype de départ : les fonctions sensibles ne doivent pas être automatisées sans autorisations Android explicites et confirmations claires.
