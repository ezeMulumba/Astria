package com.lux.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Service d'accessibilité : il sert uniquement à toucher les touches de la calculatrice
 * quand vous l'avez demandé et confirmé. Il ne lit rien d'autre.
 */
class LuxAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: LuxAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Tape l'expression (ex. "12*5") puis "=" dans la calculatrice ouverte. */
    fun typeOnCalculator(expr: String) {
        Thread {
            // Attendre que la calculatrice soit à l'écran (4 secondes maximum)
            var waited = 0
            while (waited < 4000 && !calculatorVisible()) {
                Thread.sleep(250)
                waited += 250
            }
            Thread.sleep(600)

            click(listOf("C", "AC", "Effacer", "Tout effacer", "Clear", "Supprimer tout"))
            Thread.sleep(200)

            for (ch in expr) {
                val ok = click(labelsFor(ch))
                if (!ok) return@Thread
                Thread.sleep(180)
            }
            click(listOf("=", "égal", "Égal", "equals"))
        }.start()
    }

    private fun calculatorVisible(): Boolean {
        val pkg = rootInActiveWindow?.packageName?.toString()?.lowercase() ?: return false
        return pkg.contains("calc")
    }

    private fun labelsFor(ch: Char): List<String> = when (ch) {
        '+' -> listOf("+", "plus", "Plus")
        '-' -> listOf("-", "−", "–", "moins", "Moins")
        '*' -> listOf("×", "x", "*", "fois", "multiplier", "Multiplier")
        '/' -> listOf("÷", "/", "diviser", "Diviser", "divisé par")
        '.' -> listOf(".", ",", "point", "virgule")
        else -> listOf(ch.toString())
    }

    private fun click(labels: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        for (label in labels) {
            for (node in root.findAccessibilityNodeInfosByText(label)) {
                val text = node.text?.toString()
                val desc = node.contentDescription?.toString()
                if (text.equals(label, ignoreCase = true) || desc.equals(label, ignoreCase = true)) {
                    var target: AccessibilityNodeInfo? = node
                    while (target != null && !target.isClickable) target = target.parent
                    if (target != null && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                }
            }
        }
        return false
    }
}
