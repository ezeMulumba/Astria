package com.lux.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale

/**
 * Le cœur de Lux : un service permanent qui
 *  1. écoute en continu le mot « Lux » (état WAKE),
 *  2. écoute la demande (COMMAND),
 *  3. demande confirmation avant toute action sur le téléphone (CONFIRM),
 *  4. répond toujours à voix haute.
 */
class LuxService : Service() {

    private enum class State { WAKE, COMMAND, CONFIRM }

    companion object {
        const val ACTION_TEST = "com.lux.assistant.TEST"
        private const val CHANNEL = "lux_channel"
        @Volatile var running = false
        @Volatile var lastLog = ""
    }

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var state = State.WAKE
    private var speaking = false
    private var busy = false
    private var pending: Plan? = null
    private var confirmTries = 0
    private var pendingTest = false
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var gemini: GeminiClient
    private lateinit var actions: PhoneActions

    private val wake = Regex("\\b(lux|luxe|lucks|luc's|lucs)\\b")
    private val startRunnable = Runnable { startListening() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        gemini = GeminiClient({ Prefs.key(this) }, { Prefs.model(this) })
        actions = PhoneActions(this)
        startInForeground()
        initTts()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Lux:listen").also { it.acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        running = true
        Prefs.setServiceWanted(this, true)
        if (intent?.action == ACTION_TEST) {
            if (ttsReady) testVoice() else pendingTest = true
        } else if (ttsReady) {
            startListeningSoon(300)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        Prefs.setServiceWanted(this, false)
        main.removeCallbacksAndMessages(null)
        stopRecognizer()
        tts?.stop()
        tts?.shutdown()
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) { /* rien */ }
        super.onDestroy()
    }

    // ---------- Notification (obligatoire pour écouter en permanence) ----------

    private fun startInForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Lux en veille", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Lux est en veille")
            .setContentText("Dites « Lux » pour me parler.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- Voix ----------

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status != TextToSpeech.SUCCESS) {
                lastLog = "La synthèse vocale n'a pas démarré."
                return@TextToSpeech
            }
            val t = tts ?: return@TextToSpeech
            t.language = Locale.FRANCE
            t.setPitch(1.25f)        // timbre un peu plus aigu
            t.setSpeechRate(1.0f)
            applySavedVoice(t)
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    main.post { onSpeechDone() }
                }
                override fun onError(utteranceId: String?) {
                    main.post { onSpeechDone() }
                }
            })
            ttsReady = true
            main.post {
                if (pendingTest) {
                    pendingTest = false
                    testVoice()
                } else {
                    startListeningSoon(300)
                }
            }
        }
    }

    private fun frenchVoices(): List<Voice> = try {
        tts?.voices?.filter { it.locale.language == "fr" }?.sortedBy { it.name } ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    private fun applySavedVoice(t: TextToSpeech) {
        try {
            val voices = frenchVoices()
            val saved = Prefs.voice(this)
            val v = voices.firstOrNull { it.name == saved }
                ?: voices.firstOrNull { it.name.contains("female", ignoreCase = true) }
                ?: voices.firstOrNull { Regex("-(fra|frc)-").containsMatchIn(it.name) }
                ?: voices.firstOrNull { it.locale.country == "FR" }
            if (v != null) t.voice = v
        } catch (e: Exception) { /* on garde la voix par défaut */ }
    }

    /** Passe à la voix française suivante et la mémorise. */
    private fun nextVoice() {
        val voices = frenchVoices()
        if (voices.isEmpty()) return
        val idx = voices.indexOfFirst { it.name == tts?.voice?.name }
        val next = voices[(idx + 1) % voices.size]
        tts?.voice = next
        Prefs.setVoice(this, next.name)
    }

    private fun testVoice() {
        nextVoice()
        state = State.WAKE
        speak("Bonjour, je suis Lux. Cette voix vous plaît ? Appuyez encore sur le bouton pour en essayer une autre.")
    }

    private fun speak(text: String) {
        lastLog = "Lux : $text"
        val t = tts
        if (t == null || !ttsReady) {
            startListeningSoon(300)
            return
        }
        speaking = true
        stopRecognizer()
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lux-" + System.currentTimeMillis())
    }

    private fun onSpeechDone() {
        speaking = false
        startListeningSoon(250)
    }

    // ---------- Écoute ----------

    private fun startListeningSoon(delayMs: Long) {
        main.removeCallbacks(startRunnable)
        main.postDelayed(startRunnable, delayMs)
    }

    private fun startListening() {
        if (!running || speaking || busy) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            lastLog = "La reconnaissance vocale de Google n'est pas disponible sur ce téléphone."
            return
        }
        stopRecognizer()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(listener)
        recognizer = r
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try {
            r.startListening(i)
        } catch (e: Exception) {
            startListeningSoon(1500)
        }
    }

    private fun stopRecognizer() {
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) { /* rien */ }
        recognizer = null
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            main.post {
                when (error) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        lastLog = "L'autorisation du micro manque : ouvrez Lux, étape 2."
                        stopSelf()
                    }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> startListeningSoon(1200)
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        when (state) {
                            State.CONFIRM -> askAgain()
                            State.COMMAND -> {
                                state = State.WAKE
                                startListeningSoon(250)
                            }
                            State.WAKE -> startListeningSoon(250)
                        }
                    }
                    else -> startListeningSoon(1500)
                }
            }
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
            main.post { handle(list) }
        }
    }

    // ---------- Compréhension ----------

    private fun handle(alts: List<String>) {
        if (!running) return
        val first = alts.firstOrNull()?.trim().orEmpty()
        when (state) {
            State.WAKE -> {
                val src = alts.map { it.lowercase(Locale.FRENCH) }.firstOrNull { wake.containsMatchIn(it) }
                if (src == null) {
                    startListeningSoon(150)
                    return
                }
                val m = wake.find(src)!!
                val after = src.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?')
                val before = src.substring(0, m.range.first).trim(' ', ',', '.', '!', '?')
                when {
                    after.length >= 2 -> process(after)
                    before.length >= 3 -> process(before)
                    else -> {
                        state = State.COMMAND
                        speak("Oui monsieur, je vous écoute.")
                    }
                }
            }
            State.COMMAND -> if (first.isBlank()) startListeningSoon(150) else process(first.lowercase(Locale.FRENCH))
            State.CONFIRM -> confirm(first.lowercase(Locale.FRENCH))
        }
    }

    private fun process(cmd: String) {
        lastLog = "Vous : $cmd"

        if (Regex("mets[- ]toi en veille|arrête[- ]toi|tais[- ]toi|silence").containsMatchIn(cmd)) {
            state = State.WAKE
            speak("D'accord, je me mets en veille.")
            return
        }
        if (Regex("nouvelle conversation|oublie (tout|la conversation)").containsMatchIn(cmd)) {
            gemini.reset()
            state = State.COMMAND
            speak("C'est fait, on repart de zéro.")
            return
        }
        if (Regex("change de voix|autre voix|voix suivante").containsMatchIn(cmd)) {
            nextVoice()
            state = State.COMMAND
            speak("Voici une autre voix. Elle vous plaît ?")
            return
        }

        val plan = try { actions.plan(cmd) } catch (e: Exception) { null }
        if (plan != null) {
            if (!plan.needsConfirm) {
                state = State.COMMAND
                speak(try { plan.run() } catch (e: Exception) { "Je n'ai pas réussi." })
            } else {
                pending = plan
                confirmTries = 0
                state = State.CONFIRM
                speak(plan.question)
            }
            return
        }

        // Pas une action téléphone : on demande à Gemini (avec mémoire et recherche web)
        busy = true
        stopRecognizer()
        Thread {
            val answer = gemini.ask(cmd)
            main.post {
                busy = false
                state = State.COMMAND
                speak(answer)
            }
        }.start()
    }

    private fun confirm(text: String) {
        val yes = Regex("\\b(oui|ouais|ok|d'accord|vas-y|vas y|allez|confirme|confirmé|bien sûr)\\b")
        val no = Regex("\\b(non|annule|annuler|laisse tomber|pas du tout)\\b")
        when {
            no.containsMatchIn(text) -> {
                pending = null
                state = State.COMMAND
                speak("D'accord, j'annule.")
            }
            yes.containsMatchIn(text) -> {
                val p = pending
                pending = null
                state = State.COMMAND
                speak(try { p?.run() ?: "" } catch (e: Exception) { "Je n'ai pas réussi à le faire." })
            }
            else -> askAgain()
        }
    }

    private fun askAgain() {
        confirmTries++
        if (confirmTries > 2) {
            pending = null
            state = State.WAKE
            speak("Je laisse tomber.")
        } else {
            speak("Dites oui ou non. " + (pending?.question ?: ""))
        }
    }
}
