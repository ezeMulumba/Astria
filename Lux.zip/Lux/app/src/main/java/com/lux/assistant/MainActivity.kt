package com.lux.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/** Écran d'accueil : la checklist de ce qu'il faut régler pour que Lux fonctionne. */
class MainActivity : AppCompatActivity() {

    private lateinit var etKey: EditText
    private lateinit var etModel: EditText
    private lateinit var tvKey: TextView
    private lateinit var tvPerms: TextView
    private lateinit var tvAccess: TextView
    private lateinit var tvOverlay: TextView
    private lateinit var tvBattery: TextView
    private lateinit var tvService: TextView
    private lateinit var tvLog: TextView

    private val ok = "✅ "
    private val ko = "❌ "

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etKey = findViewById(R.id.etKey)
        etModel = findViewById(R.id.etModel)
        tvKey = findViewById(R.id.tvKey)
        tvPerms = findViewById(R.id.tvPerms)
        tvAccess = findViewById(R.id.tvAccess)
        tvOverlay = findViewById(R.id.tvOverlay)
        tvBattery = findViewById(R.id.tvBattery)
        tvService = findViewById(R.id.tvService)
        tvLog = findViewById(R.id.tvLog)

        etKey.setText(Prefs.key(this))
        etModel.setText(Prefs.rawModel(this))

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            Prefs.save(this, etKey.text.toString(), etModel.text.toString())
            Toast.makeText(this, "Clé enregistrée", Toast.LENGTH_SHORT).show()
            refresh()
        }

        findViewById<Button>(R.id.btnPerms).setOnClickListener {
            ActivityCompat.requestPermissions(this, neededPermissions(), 100)
        }

        findViewById<Button>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }

        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            Prefs.save(this, etKey.text.toString(), etModel.text.toString())
            if (!hasMic()) {
                Toast.makeText(this, "Autorisez d'abord le micro (étape 2).", Toast.LENGTH_LONG).show()
                ActivityCompat.requestPermissions(this, neededPermissions(), 100)
            } else {
                startLux(null)
                Toast.makeText(this, "Lux est en veille. Dites « Lux ».", Toast.LENGTH_LONG).show()
            }
            refresh()
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, LuxService::class.java))
            refresh()
        }

        findViewById<Button>(R.id.btnTest).setOnClickListener {
            if (!hasMic()) {
                ActivityCompat.requestPermissions(this, neededPermissions(), 100)
            } else {
                startLux(LuxService.ACTION_TEST)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun startLux(action: String?) {
        val i = Intent(this, LuxService::class.java)
        if (action != null) i.action = action
        ContextCompat.startForegroundService(this, i)
    }

    private fun neededPermissions(): Array<String> {
        val list = arrayListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        return list.toTypedArray()
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun hasMic() = has(Manifest.permission.RECORD_AUDIO)

    private fun accessibilityOn(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return enabled.contains(packageName, ignoreCase = true)
    }

    private fun batteryOk(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun refresh() {
        tvKey.text = if (Prefs.key(this).isNotBlank()) ok + "Clé Gemini enregistrée" else ko + "Clé Gemini manquante"

        val missing = ArrayList<String>()
        if (!hasMic()) missing.add("micro")
        if (!has(Manifest.permission.READ_CONTACTS)) missing.add("contacts")
        if (!has(Manifest.permission.CALL_PHONE)) missing.add("téléphone")
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) missing.add("notifications")
        tvPerms.text = if (missing.isEmpty()) ok + "Micro, contacts, téléphone, notifications"
        else ko + "Il manque : " + missing.joinToString(", ")

        tvAccess.text = if (accessibilityOn()) ok + "Accessibilité activée"
        else ko + "Accessibilité désactivée : dans la liste, ouvrez « Lux » puis activez-la."

        tvOverlay.text = if (Settings.canDrawOverlays(this)) ok + "Affichage par-dessus les autres applis autorisé"
        else ko + "À autoriser : sinon Android peut bloquer l'ouverture des applis quand l'écran est éteint."

        tvBattery.text = if (batteryOk()) ok + "Batterie : Lux n'est pas restreinte"
        else ko + "Batterie : à régler, sinon Android coupera Lux"

        tvService.text = if (LuxService.running) ok + "Lux est en veille, dites « Lux »"
        else ko + "Lux est arrêtée"

        tvLog.text = LuxService.lastLog
    }
}
