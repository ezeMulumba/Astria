package com.lux.assistant

import android.content.Context

/** Stockage simple des réglages (clé Gemini, modèle, voix). */
object Prefs {
    private const val FILE = "lux_prefs"
    const val DEFAULT_MODEL = "gemini-2.5-flash"

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun key(c: Context): String = sp(c).getString("key", "") ?: ""
    fun model(c: Context): String =
        (sp(c).getString("model", "") ?: "").ifBlank { DEFAULT_MODEL }
    fun rawModel(c: Context): String = sp(c).getString("model", "") ?: ""

    fun save(c: Context, key: String, model: String) {
        sp(c).edit().putString("key", key.trim()).putString("model", model.trim()).apply()
    }

    fun voice(c: Context): String = sp(c).getString("voice", "") ?: ""
    fun setVoice(c: Context, name: String) = sp(c).edit().putString("voice", name).apply()

    fun serviceWanted(c: Context) = sp(c).getBoolean("service_on", false)
    fun setServiceWanted(c: Context, on: Boolean) =
        sp(c).edit().putBoolean("service_on", on).apply()
}
