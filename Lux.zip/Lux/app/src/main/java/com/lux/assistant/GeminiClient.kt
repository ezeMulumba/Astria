package com.lux.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Appelle Gemini et garde la mémoire de la conversation :
 * à chaque question, les derniers échanges sont renvoyés avec elle.
 * La recherche Google est activée pour que Lux puisse chercher sur le web.
 */
class GeminiClient(private val keyProvider: () -> String, private val modelProvider: () -> String) {

    private val history = ArrayList<Pair<String, String>>() // ("user"|"model", texte)
    private val maxTurns = 20 // 20 messages = 10 échanges

    private val system = """
        Tu es Lux, l'assistante vocale personnelle de Monsieur. Tu parles français,
        avec un ton féminin, doux, clair et professionnel. Tes réponses sont lues à voix haute :
        fais court (une à quatre phrases), sans listes, sans symboles, sans markdown, sans émojis.
        Tiens compte de toute la conversation, pas seulement de la dernière phrase.
        Pour toute information récente ou factuelle, utilise la recherche web.
        Si tu ne sais pas, dis-le simplement.
    """.trimIndent()

    fun reset() = history.clear()

    /** Appel bloquant : à lancer dans un thread. */
    fun ask(userText: String): String {
        val key = keyProvider()
        if (key.isBlank()) return "Je n'ai pas encore de clé Gemini. Ouvrez l'application Lux et collez-la à l'étape un."

        history.add("user" to userText)
        while (history.size > maxTurns) history.removeAt(0)

        val contents = JSONArray()
        for ((role, text) in history) {
            contents.put(
                JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))

        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${modelProvider()}:generateContent")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 40000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = conn.responseCode
            val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""

            if (code !in 200..299) {
                history.removeAt(history.size - 1)
                return when (code) {
                    400, 403 -> "Gemini a refusé ma clé. Vérifiez-la dans l'application Lux."
                    404 -> "Le modèle Gemini choisi n'existe pas. Changez le nom du modèle dans l'application."
                    429 -> "J'ai atteint la limite gratuite de Gemini. Réessayez dans une minute."
                    else -> "Gemini a répondu avec l'erreur $code."
                }
            }

            val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            val answer = sb.toString().trim().ifBlank { "Je n'ai pas de réponse pour cela." }
            history.add("model" to answer)
            answer
        } catch (e: Exception) {
            history.removeAt(history.size - 1)
            "Je n'arrive pas à joindre Internet pour le moment."
        }
    }
}
