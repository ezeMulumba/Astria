package com.lux.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Une action prête à exécuter : la question de confirmation et ce qu'il faut faire. */
class Plan(val question: String, val needsConfirm: Boolean, val run: () -> String)

/**
 * Tout ce qui touche au téléphone est géré ICI, en local, par des règles simples.
 * Gemini n'est utilisé que pour les questions et la recherche web : c'est plus fiable.
 */
class PhoneActions(private val ctx: Context) {

    fun plan(raw: String): Plan? {
        val t = raw.lowercase(Locale.FRENCH).trim()

        // Heure et date : lecture seule, pas de confirmation
        if (Regex("quelle heure|il est quelle heure").containsMatchIn(t)) {
            return Plan("", false) {
                "Il est " + SimpleDateFormat("H 'heures' mm", Locale.FRENCH).format(Date()) + "."
            }
        }
        if (Regex("quel jour|quelle date|on est le combien").containsMatchIn(t)) {
            return Plan("", false) {
                "Nous sommes le " + SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH).format(Date()) + "."
            }
        }

        // Appeler quelqu'un
        val call = Regex("(?:appelle|appeler|téléphone à|passe un appel à|contacte)\\s+(?:le\\s+|la\\s+|l'|mon\\s+|ma\\s+)?(.+)").find(t)
        if (call != null) {
            val name = call.groupValues[1].trim()
            val digits = name.replace(Regex("[\\s.-]"), "")
            if (digits.matches(Regex("\\+?\\d{6,}"))) {
                return Plan("Je vais appeler le ${name}. Vous confirmez ?", true) { dial(digits) }
            }
            val contact = findContact(name)
                ?: return Plan("", false) { "Je ne trouve pas $name dans vos contacts, ou l'autorisation des contacts manque." }
            return Plan("Je vais appeler ${contact.first}. Vous confirmez ?", true) { dial(contact.second) }
        }

        // Ouvrir une application
        val open = Regex("(?:ouvre|ouvrir|lance|lancer|démarre|démarrer)\\s+(?:l'application\\s+|l'appli\\s+|application\\s+|le\\s+|la\\s+|l'|les\\s+)?(.+)").find(t)
        if (open != null) {
            val name = open.groupValues[1].trim()
            val n = normalize(name)
            if (n.startsWith("calculatrice") || n.startsWith("calculette") || n.startsWith("calculator")) {
                return Plan("Je vais ouvrir la calculatrice. Vous confirmez ?", true) {
                    if (openCalculator()) "La calculatrice est ouverte." else "Je ne trouve pas de calculatrice sur ce téléphone."
                }
            }
            if (n.startsWith("galerie") || n.startsWith("gallery") || n.startsWith("photos")) {
                return Plan("Je vais ouvrir la galerie. Vous confirmez ?", true) {
                    if (openGallery()) "La galerie est ouverte." else "Je ne trouve pas de galerie sur ce téléphone."
                }
            }
            return Plan("Je vais ouvrir $name. Vous confirmez ?", true) {
                val label = openAppByLabel(name)
                if (label != null) "$label est ouverte." else "Je ne trouve pas d'application nommée $name."
            }
        }

        // Calcul
        val calc = parseCalculation(t)
        if (calc != null) {
            val expr = calc.first
            val spoken = formatNumber(calc.second)
            val say = expr.replace("*", " fois ").replace("/", " divisé par ").replace("+", " plus ").replace("-", " moins ")
            return Plan("Je vais calculer $say dans la calculatrice. Vous confirmez ?", true) {
                openCalculator()
                val svc = LuxAccessibilityService.instance
                if (svc != null) {
                    svc.typeOnCalculator(expr)
                    "Le résultat est $spoken."
                } else {
                    "Le résultat est $spoken. Pour que j'écrive dans la calculatrice, activez l'accessibilité de Lux."
                }
            }
        }

        return null
    }

    // ---------- Actions ----------

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val c: Context = LuxAccessibilityService.instance ?: ctx
        c.startActivity(i)
    }

    private fun dial(number: String): String {
        return try {
            val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            val action = if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL
            start(Intent(action, Uri.parse("tel:" + Uri.encode(number))))
            if (granted) "J'appelle." else "Le numéro est prêt, appuyez sur appeler."
        } catch (e: Exception) {
            "Je n'ai pas réussi à lancer l'appel."
        }
    }

    private fun openCalculator(): Boolean {
        try {
            start(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR))
            return true
        } catch (e: Exception) { /* on essaie autrement */ }
        return openAppByLabel("calculatrice") != null ||
            openAppByLabel("calculette") != null ||
            openAppByLabel("calculator") != null
    }

    private fun openGallery(): Boolean {
        try {
            start(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY))
            return true
        } catch (e: Exception) { /* on essaie autrement */ }
        if (openAppByLabel("galerie") != null || openAppByLabel("gallery") != null || openAppByLabel("photos") != null) return true
        return try {
            start(Intent(Intent.ACTION_VIEW).setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*"))
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Ouvre l'application dont le nom ressemble à [name]. Retourne son nom, ou null. */
    private fun openAppByLabel(name: String): String? {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val target = normalize(name)
        val match = apps.firstOrNull { normalize(it.loadLabel(pm).toString()) == target }
            ?: apps.firstOrNull { normalize(it.loadLabel(pm).toString()).contains(target) }
            ?: return null
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return null
        return try {
            start(launch)
            match.loadLabel(pm).toString()
        } catch (e: Exception) {
            null
        }
    }

    private fun findContact(name: String): Pair<String, String>? {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        ) ?: return null
        val target = normalize(name)
        val words = target.split(" ").filter { it.isNotEmpty() }
        var best: Pair<String, String>? = null
        var bestScore = 0
        cursor.use { c ->
            while (c.moveToNext()) {
                val display = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val n = normalize(display)
                val score = when {
                    n == target -> 3
                    n.startsWith(target) -> 2
                    words.isNotEmpty() && words.all { w -> n.contains(w) } -> 1
                    else -> 0
                }
                if (score > bestScore) {
                    bestScore = score
                    best = display to number
                }
            }
        }
        return best
    }

    // ---------- Calcul ----------

    /** Retourne (expression normalisée, résultat) ou null si ce n'est pas un calcul. */
    private fun parseCalculation(t: String): Pair<String, Double>? {
        val s = t
            .replace("multiplié par", "*").replace("divisé par", "/")
            .replace("×", "*").replace("÷", "/")
            .replace(Regex("(?<=\\d)\\s*x\\s*(?=\\d)"), "*")
            .replace(" fois ", "*").replace(" plus ", "+").replace(" moins ", "-")
            .replace(Regex("(?<=\\d)\\s*(?:virgule|,)\\s*(?=\\d)"), ".")
        val m = Regex("\\d+(?:\\.\\d+)?(?:\\s*[+\\-*/]\\s*\\d+(?:\\.\\d+)?)+").find(s) ?: return null
        val wantsCalc = Regex("calcul|combien|fait|font|résultat|égal|egal").containsMatchIn(t) || s.trim() == m.value.trim()
        if (!wantsCalc) return null
        val expr = m.value.replace(Regex("\\s"), "")
        val value = evaluate(expr) ?: return null
        return expr to value
    }

    private fun evaluate(e: String): Double? {
        val tokens = Regex("\\d+(?:\\.\\d+)?|[+\\-*/]").findAll(e).map { it.value }.toList()
        if (tokens.isEmpty() || tokens.size % 2 == 0) return null
        val terms = ArrayList<Double>()
        val ops = ArrayList<Char>()
        var cur = tokens[0].toDoubleOrNull() ?: return null
        var i = 1
        while (i < tokens.size) {
            val op = tokens[i][0]
            val n = tokens[i + 1].toDoubleOrNull() ?: return null
            when (op) {
                '*' -> cur *= n
                '/' -> {
                    if (n == 0.0) return null
                    cur /= n
                }
                else -> {
                    terms.add(cur)
                    ops.add(op)
                    cur = n
                }
            }
            i += 2
        }
        terms.add(cur)
        var res = terms[0]
        for (k in ops.indices) res = if (ops[k] == '+') res + terms[k + 1] else res - terms[k + 1]
        return res
    }

    private fun formatNumber(v: Double): String =
        if (v == Math.rint(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else String.format(Locale.FRENCH, "%.6f", v).trimEnd('0').trimEnd(',').replace(",", " virgule ")

    private fun normalize(s: String): String =
        Normalizer.normalize(s.lowercase(Locale.FRENCH), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
}
