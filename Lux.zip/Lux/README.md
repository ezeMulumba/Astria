# Lux — assistante vocale Android

## Obtenir l'APK avec GitHub
1. Sur GitHub, créez un dépôt (par exemple `LUX`) et envoyez-y tous les fichiers de ce dossier.
2. Vérifiez que le fichier `.github/workflows/build.yml` est bien présent (dossier caché). S'il manque :
   « Add file » → « Create new file », nom : `.github/workflows/build.yml`, puis collez son contenu.
3. Onglet **Actions** → « Construire l'APK Lux » → **Run workflow**. Attendez 5 à 10 minutes.
4. Ouvrez l'exécution terminée, descendez à « Artifacts » et téléchargez **Lux-APK**. Dézippez : `app-debug.apk`.
5. Installez l'APK sur le téléphone (autorisez les sources inconnues si Android le demande).

## Premier lancement (l'écran d'accueil de Lux le rappelle)
1. **Clé Gemini** : sur aistudio.google.com → « Get API key », copiez la clé gratuite, collez-la dans Lux, « Enregistrer ».
2. **Autorisations** : micro, contacts, téléphone, notifications ; accessibilité (activer « Lux ») ; affichage par-dessus les autres applis ; batterie sans restriction.
   Sur Tecno / Infinix / Itel / Xiaomi : autorisez aussi le démarrage automatique et l'activité en arrière-plan dans les réglages de l'appli.
3. **Activer Lux (mode veille)**, puis dites : « Lux, ouvre la calculatrice », « Lux, calcule 12 fois 5 », « Lux, appelle Maman », « Lux, ouvre la galerie », « Lux, quelle est la météo à Kinshasa ? ».

## Commandes utiles
- « Lux, change de voix » : passe à la voix française suivante (mémorisée).
- « Lux, nouvelle conversation » : efface la mémoire des échanges.
- « Lux, mets-toi en veille » : elle ne répond plus qu'au mot « Lux ».

## Si la compilation échoue
Ouvrez l'exécution en échec dans l'onglet Actions, copiez les dernières lignes rouges et envoyez-les moi.
